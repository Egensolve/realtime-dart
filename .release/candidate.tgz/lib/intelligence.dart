
library;

export 'src/intelligence/intelligence_client.dart' show IntelligenceClient;
