



library;

export 'src/lifecycle/ports.dart'
    show
        TransportCloseEvent,
        SocketTransportHandlers,
        SocketConnection,
        SocketTransportPort,
        ClockPort,
        SchedulerHandle,
        SchedulerPort,
        LifecycleSignalKind,
        LifecycleSignal,
        LifecycleSignalSource,
        LifecycleBootstrapConfig,
        BackoffPolicy,
        DedupPolicy,
        AuthCallbackRequest,
        AuthCallbackResponse,
        AuthCallbackPort,
        RecoveryReason,
        RecoveryContext,
        RecoveryCoordinatorPort,
        RecoveryScope,
        RecoveryApplyRequest,
        RecoveryApplyResult,
        RecoveryHandler,
        EnvelopeDropReason,
        TelemetryEventKind,
        TelemetryEvent,
        StateTransitionTelemetryEvent,
        ReconnectAttemptTelemetryEvent,
        EnvelopeDroppedTelemetryEvent,
        EventDispatchedTelemetryEvent,
        UnknownTypeIgnoredTelemetryEvent,
        RecoveryRequestedTelemetryEvent,
        SubscriptionIntentTelemetryEvent,
        SubscriptionResultTelemetryEvent,
        RecoveryAppliedTelemetryEvent,
        RecoveryApplyFailedTelemetryEvent,
        RecoverySupersededTelemetryEvent,
        CursorCorruptedTelemetryEvent,
        SessionResetTelemetryEvent,
        TelemetrySinkPort,
        CursorStorePort,
        OutgoingMessageRecord,
        OutgoingMessageOutboxPort,
        IntentKind,
        SubscriptionIntent,
        SubscriptionIntentRegistry,
        DurableEventDeduplicator,
        DecodeResult,
        DecodeOk,
        DecodeFailed,
        EnvelopeDecoderPort,
        EventHandler,
        UnknownTypeHandler,
        EventDispatcher,
        EphemeralPublishRequest,
        EphemeralPublishPort;
export 'src/lifecycle/state.dart'
    show LifecycleState, validTransitions, isValidTransition;
export 'src/lifecycle/backoff.dart' show RandomSource, computeBackoffDelayMs;
export 'src/lifecycle/dedup.dart' show BoundedDurableEventDeduplicator;
export 'src/lifecycle/intent_registry.dart'
    show DefaultSubscriptionIntentRegistry;
export 'src/lifecycle/envelope_decoder.dart'
    show ContractsEnvelopeDecoder, defaultEnvelopeDecoder;
export 'src/lifecycle/event_dispatcher.dart' show DomainEventDispatcher;
export 'src/lifecycle/client.dart' show RealtimeLifecycleClient;
export 'src/lifecycle/recovery/coordinator.dart'
    show DefaultRecoveryCoordinator, RecoveryScopeBinding;
export 'src/lifecycle/presence.dart'
    show
        PresenceMember,
        PresenceEvent,
        PresenceSnapshot,
        PresenceMemberJoined,
        PresenceMemberLeft,
        parsePresenceHash,
        parseMemberEventData;
export 'src/lifecycle/ephemeral_event_types.dart'
    show presenceDomain, typingStartedType, typingStoppedType;
export 'src/lifecycle/typing.dart'
    show RoomTypingSender, TypingIndicatorTracker;
export 'src/lifecycle/id_generator.dart' show IdGenerator, generateEventId;
