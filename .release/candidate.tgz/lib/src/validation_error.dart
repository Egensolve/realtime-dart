


enum ValidationErrorCode {
  envelopeInvalidJson('envelope.invalid_json'),
  envelopeTooLarge('envelope.too_large'),
  envelopeMissingField('envelope.missing_field'),
  envelopeUnsupportedVersion('envelope.unsupported_version'),
  envelopeInvalidKind('envelope.invalid_kind'),
  envelopeRecoveryRequired('envelope.recovery_required'),
  envelopeRecoveryNotAllowed('envelope.recovery_not_allowed'),
  envelopeExpiresAtRequired('envelope.expires_at_required'),
  envelopeExpiresAtNotAllowed('envelope.expires_at_not_allowed'),
  envelopeInvalidId('envelope.invalid_id'),
  envelopeInvalidDomain('envelope.invalid_domain'),
  envelopeInvalidType('envelope.invalid_type'),
  envelopeInvalidTenant('envelope.invalid_tenant'),
  envelopeInvalidTimestamp('envelope.invalid_timestamp'),
  envelopeInvalidSubject('envelope.invalid_subject'),
  envelopeInvalidRecovery('envelope.invalid_recovery'),
  envelopePayloadNotObject('envelope.payload_not_object'),
  envelopePayloadBinaryRejected('envelope.payload_binary_rejected'),
  channelInvalidFormat('channel.invalid_format'),
  channelInvalidSegment('channel.invalid_segment'),
  channelTooLong('channel.too_long');

  const ValidationErrorCode(this.wireValue);

  final String wireValue;
}

enum ValidationErrorCategory {
  parse('parse'),
  sizeLimit('size_limit'),
  schema('schema'),
  grammar('grammar');

  const ValidationErrorCategory(this.wireValue);

  final String wireValue;
}




final class ValidationError implements Exception {
  const ValidationError({
    required this.code,
    required this.category,
    required this.message,
    this.path,
    this.details = const {},
  });

  final ValidationErrorCode code;
  final ValidationErrorCategory category;
  final String message;
  final String? path;
  final Map<String, Object> details;

  
  Map<String, Object> toMap() {
    return {
      'code': code.wireValue,
      'category': category.wireValue,
      'message': message,
      if (path != null) 'path': path!,
      if (details.isNotEmpty) 'details': details,
    };
  }

  @override
  String toString() => 'ValidationError(${code.wireValue}: $message)';
}
