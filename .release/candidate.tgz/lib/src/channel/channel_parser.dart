import '../validation_error.dart';
import 'channel.dart';




final class ChannelParser {
  const ChannelParser._();

  static Channel parse(String channel) {
    requireWithinMaxLength(channel);

    final parts = channel.split('.');
    final count = parts.length;

    if (count == 6 &&
        parts[0] == 'private-v1' &&
        parts[1] == 'tenants' &&
        parts[3] == 'accounts') {
      return AccountChannel(
          tenant: parts[2], actorType: parts[4], actorId: parts[5]);
    }
    if (count == 5 &&
        parts[0] == 'private-v1' &&
        parts[1] == 'tenants' &&
        parts[3] == 'devices') {
      return DeviceChannel(tenant: parts[2], deviceId: parts[4]);
    }
    if (count == 6 &&
        parts[0] == 'presence-v1' &&
        parts[1] == 'tenants' &&
        parts[3] == 'rooms') {
      return RoomChannel(
          tenant: parts[2], roomType: parts[4], roomId: parts[5]);
    }
    if (count == 5 &&
        parts[0] == 'private-v1' &&
        parts[1] == 'tenants' &&
        parts[3] == 'systems') {
      return SystemChannel(tenant: parts[2], scope: parts[4]);
    }
    if (count == 5 &&
        parts[0] == 'private-v2' &&
        parts[1] == 'tenants' &&
        parts[3] == 'calls') {
      return CallChannel(tenant: parts[2], callId: parts[4]);
    }

    throw const ValidationError(
      code: ValidationErrorCode.channelInvalidFormat,
      category: ValidationErrorCategory.grammar,
      message: 'Channel name does not match a supported versioned shape.',
    );
  }
}
