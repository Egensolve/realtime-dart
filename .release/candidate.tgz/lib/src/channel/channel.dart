import '../validation_error.dart';

const int channelMaxLength = 164;

final RegExp _channelToken = RegExp(r'^[a-z][a-z0-9]*(-[a-z0-9]+)*$');
final RegExp _channelOpaqueId = RegExp(r'^[A-Za-z0-9_-]+$');



String requireOpaqueId(String value, String fieldName, {int maxLength = 64}) {
  if (value.isEmpty ||
      value.length > maxLength ||
      !_channelOpaqueId.hasMatch(value)) {
    throw ValidationError(
      code: ValidationErrorCode.channelInvalidSegment,
      category: ValidationErrorCategory.grammar,
      message:
          '$fieldName must be 1-$maxLength characters of letters, digits, "_", or "-".',
      details: {'field': fieldName},
    );
  }
  return value;
}

String requireToken(String value, String fieldName, {int maxLength = 32}) {
  if (value.isEmpty ||
      value.length > maxLength ||
      !_channelToken.hasMatch(value)) {
    throw ValidationError(
      code: ValidationErrorCode.channelInvalidSegment,
      category: ValidationErrorCategory.grammar,
      message:
          '$fieldName must be a lowercase ASCII token of at most $maxLength characters.',
      details: {'field': fieldName},
    );
  }
  return value;
}

String requireWithinMaxLength(String channel) {
  if (channel.length > channelMaxLength) {
    throw ValidationError(
      code: ValidationErrorCode.channelTooLong,
      category: ValidationErrorCategory.grammar,
      message: 'Channel name exceeds the $channelMaxLength character limit.',
    );
  }
  return channel;
}





sealed class Channel {
  const Channel();

  String get tenant;

  String toChannelString();
}



final class AccountChannel extends Channel {
  factory AccountChannel({
    required String tenant,
    required String actorType,
    required String actorId,
  }) {
    return AccountChannel._(
      requireOpaqueId(tenant, 'tenant'),
      requireToken(actorType, 'actorType'),
      requireOpaqueId(actorId, 'actorId'),
    );
  }

  const AccountChannel._(this.tenant, this.actorType, this.actorId);

  @override
  final String tenant;
  final String actorType;
  final String actorId;

  @override
  String toChannelString() => requireWithinMaxLength(
      'private-v1.tenants.$tenant.accounts.$actorType.$actorId');
}



final class DeviceChannel extends Channel {
  factory DeviceChannel({required String tenant, required String deviceId}) {
    return DeviceChannel._(
      requireOpaqueId(tenant, 'tenant'),
      requireOpaqueId(deviceId, 'deviceId'),
    );
  }

  const DeviceChannel._(this.tenant, this.deviceId);

  @override
  final String tenant;
  final String deviceId;

  @override
  String toChannelString() =>
      requireWithinMaxLength('private-v1.tenants.$tenant.devices.$deviceId');
}




final class RoomChannel extends Channel {
  factory RoomChannel({
    required String tenant,
    required String roomType,
    required String roomId,
  }) {
    return RoomChannel._(
      requireOpaqueId(tenant, 'tenant'),
      requireToken(roomType, 'roomType'),
      requireOpaqueId(roomId, 'roomId'),
    );
  }

  const RoomChannel._(this.tenant, this.roomType, this.roomId);

  @override
  final String tenant;
  final String roomType;
  final String roomId;

  @override
  String toChannelString() => requireWithinMaxLength(
      'presence-v1.tenants.$tenant.rooms.$roomType.$roomId');
}



final class SystemChannel extends Channel {
  factory SystemChannel({required String tenant, required String scope}) {
    return SystemChannel._(
        requireOpaqueId(tenant, 'tenant'), requireToken(scope, 'scope'));
  }

  const SystemChannel._(this.tenant, this.scope);

  @override
  final String tenant;
  final String scope;

  @override
  String toChannelString() =>
      requireWithinMaxLength('private-v1.tenants.$tenant.systems.$scope');
}
