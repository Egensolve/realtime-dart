import '../channel/channel.dart';
import '../envelope.dart';
import 'backoff.dart';
import 'dedup.dart';
import 'envelope_decoder.dart';
import 'ephemeral_event_types.dart';
import 'event_dispatcher.dart';
import 'id_generator.dart';
import 'intent_registry.dart';
import 'ports.dart';
import 'presence.dart';
import 'transport_frame.dart';
import 'state.dart';

const BackoffPolicy _defaultBackoff =
    BackoffPolicy(baseDelayMs: 500, maxDelayMs: 30000);
const DedupPolicy _defaultDedup =
    DedupPolicy(maxEntries: 10000, maxAgeMs: 300000);

final class _NoopTelemetrySink implements TelemetrySinkPort {
  const _NoopTelemetrySink();

  @override
  void record(TelemetryEvent event) {}
}

final class _NoopSignalSource implements LifecycleSignalSource {
  const _NoopSignalSource();

  @override
  void Function() subscribe(void Function(LifecycleSignal signal) listener) {
    return () {};
  }
}






final class RealtimeLifecycleClient {
  RealtimeLifecycleClient({
    required LifecycleBootstrapConfig bootstrap,
    required SocketTransportPort transport,
    required ClockPort clock,
    required SchedulerPort scheduler,
    required AuthCallbackPort authCallback,
    required RecoveryCoordinatorPort recoveryCoordinator,
    LifecycleSignalSource signals = const _NoopSignalSource(),
    TelemetrySinkPort telemetry = const _NoopTelemetrySink(),
    EphemeralPublishPort? ephemeralPublisher,
    EnvelopeDecoderPort? envelopeDecoder,
    EventDispatcher? eventDispatcher,
    SubscriptionIntentRegistry? intentRegistry,
    DurableEventDeduplicator? dedup,
    DedupPolicy dedupPolicy = _defaultDedup,
    BackoffPolicy backoff = _defaultBackoff,
    RandomSource? random,
  })  : _bootstrap = bootstrap,
        _transport = transport,
        _clock = clock,
        _scheduler = scheduler,
        _authCallback = authCallback,
        _recoveryCoordinator = recoveryCoordinator,
        _telemetry = telemetry,
        _ephemeralPublisher = ephemeralPublisher,
        _envelopeDecoder = envelopeDecoder ?? defaultEnvelopeDecoder,
        _eventDispatcher = eventDispatcher ?? DomainEventDispatcher(),
        _intentRegistry = intentRegistry ?? DefaultSubscriptionIntentRegistry(),
        _dedup = dedup ?? BoundedDurableEventDeduplicator(dedupPolicy),
        _backoffPolicy = backoff,
        _random = random {
    _eventDispatcher.onUnknown((domain, type) {
      _record(UnknownTypeIgnoredTelemetryEvent(at: _clock.now()));
    });
    signals.subscribe(_handleLifecycleSignal);
  }

  final LifecycleBootstrapConfig _bootstrap;
  final SocketTransportPort _transport;
  final ClockPort _clock;
  final SchedulerPort _scheduler;
  final AuthCallbackPort _authCallback;
  final RecoveryCoordinatorPort _recoveryCoordinator;
  final TelemetrySinkPort _telemetry;
  final EphemeralPublishPort? _ephemeralPublisher;
  final EnvelopeDecoderPort _envelopeDecoder;
  final EventDispatcher _eventDispatcher;
  final SubscriptionIntentRegistry _intentRegistry;
  final DurableEventDeduplicator _dedup;
  final BackoffPolicy _backoffPolicy;
  final RandomSource? _random;

  LifecycleState _state = LifecycleState.idle;
  int _generation = 0;
  SocketConnection? _connection;
  String? _socketId;
  int _attempt = 0;
  SchedulerHandle? _pendingReconnectHandle;
  bool _wasUncertainDisconnect = false;
  bool _wasBackgrounded = false;
  final Set<String> _pendingSubscriptions = {};
  final Set<String> _sentSubscribeChannelsThisGeneration = {};
  final Set<void Function(LifecycleState from, LifecycleState to)>
      _stateListeners = {};

  
  RoomChannel? _activeRoomChannel;
  String? _activeRoomChannelName;
  AuthCallbackResponse? _activeRoomAuth;
  final Map<String, PresenceMember> _presenceMembers = {};
  final Set<void Function(PresenceEvent event)> _presenceListeners = {};
  final Set<void Function(RoomChannel? room)> _activeRoomChangeListeners = {};

  

  void start() {
    if (_state != LifecycleState.idle && _state != LifecycleState.stopped) {
      return;
    }
    _attempt = 0;
    _beginConnecting();
  }

  void stop() {
    if (_state == LifecycleState.idle || _state == LifecycleState.stopped) {
      return;
    }
    final pending = _pendingReconnectHandle;
    if (pending != null) {
      _scheduler.cancel(pending);
      _pendingReconnectHandle = null;
    }
    _generation++;
    final connection = _connection;
    if (connection != null) {
      connection.close(code: 1000, reason: 'client-stop');
      _connection = null;
    }
    _wasUncertainDisconnect = false;
    _transitionTo(LifecycleState.stopped);
  }

  void restart() {
    stop();
    start();
  }

  LifecycleState getState() => _state;

  void Function() onStateChange(
      void Function(LifecycleState from, LifecycleState to) listener) {
    _stateListeners.add(listener);
    return () => _stateListeners.remove(listener);
  }

  void requestRecovery() {
    _emitRecovery(RecoveryReason.manual);
  }

  
  
  
  
  
  
  void resetForSessionChange() {
    stop();
    final removed = _intentRegistry.clear();
    for (final _ in removed) {
      _record(SubscriptionIntentTelemetryEvent(
        kind: TelemetryEventKind.subscriptionIntentRemoved,
        at: _clock.now(),
      ));
    }
    _dedup.clear();
    _pendingSubscriptions.clear();
    _sentSubscribeChannelsThisGeneration.clear();
    _wasUncertainDisconnect = false;
    _wasBackgrounded = false;
    if (_activeRoomChannel != null ||
        _activeRoomChannelName != null ||
        _presenceMembers.isNotEmpty) {
      _activeRoomChannel = null;
      _activeRoomChannelName = null;
      _activeRoomAuth = null;
      _presenceMembers.clear();
      _emitPresenceEvent(const PresenceSnapshot({}));
      _notifyActiveRoomChanged(null);
    }
    _record(SessionResetTelemetryEvent(at: _clock.now()));
  }

  

  SubscriptionIntent addAccountIntent(AccountChannel channel) {
    final intent = _intentRegistry.addAccountIntent(channel);
    _record(
      SubscriptionIntentTelemetryEvent(
        kind: TelemetryEventKind.subscriptionIntentAdded,
        at: _clock.now(),
      ),
    );
    _maybeSubscribeNow();
    return intent;
  }

  SubscriptionIntent addDeviceIntent(DeviceChannel channel) {
    final intent = _intentRegistry.addDeviceIntent(channel);
    _record(
      SubscriptionIntentTelemetryEvent(
        kind: TelemetryEventKind.subscriptionIntentAdded,
        at: _clock.now(),
      ),
    );
    _maybeSubscribeNow();
    return intent;
  }

  void setActiveRoom(RoomChannel? channel) {
    SubscriptionIntent? previous;
    for (final intent in _intentRegistry.list()) {
      if (intent.kind == IntentKind.room) previous = intent;
    }
    final next = _intentRegistry.setActiveRoomIntent(channel);
    final channelChanged = previous?.channelName != next?.channelName;
    if (previous != null && channelChanged) {
      _record(
        SubscriptionIntentTelemetryEvent(
          kind: TelemetryEventKind.subscriptionIntentRemoved,
          at: _clock.now(),
        ),
      );
      _unsubscribeChannelIfSent(previous.channelName);
    }
    if (channelChanged) {
      
      
      
      
      _activeRoomChannel = channel;
      _activeRoomChannelName = next?.channelName;
      _activeRoomAuth = null;
      if (_presenceMembers.isNotEmpty) {
        _presenceMembers.clear();
        _emitPresenceEvent(const PresenceSnapshot({}));
      }
      _notifyActiveRoomChanged(channel);
    }
    if (next != null) {
      _record(
        SubscriptionIntentTelemetryEvent(
          kind: TelemetryEventKind.subscriptionIntentAdded,
          at: _clock.now(),
        ),
      );
      _maybeSubscribeNow();
    }
  }

  void setActiveCall(CallChannel? channel) {
    SubscriptionIntent? previous;
    for (final intent in _intentRegistry.list()) {
      if (intent.kind == IntentKind.call) previous = intent;
    }
    final next = _intentRegistry.setActiveCallIntent(channel);
    final channelChanged = previous?.channelName != next?.channelName;
    if (previous != null && channelChanged) {
      _record(
        SubscriptionIntentTelemetryEvent(
          kind: TelemetryEventKind.subscriptionIntentRemoved,
          at: _clock.now(),
        ),
      );
      _unsubscribeChannelIfSent(previous.channelName);
    }
    if (next != null && channelChanged) {
      _record(
        SubscriptionIntentTelemetryEvent(
          kind: TelemetryEventKind.subscriptionIntentAdded,
          at: _clock.now(),
        ),
      );
      _maybeSubscribeNow();
    }
  }

  bool removeIntent(String channelName) {
    final removed = _intentRegistry.removeIntent(channelName);
    if (removed) {
      _record(
        SubscriptionIntentTelemetryEvent(
          kind: TelemetryEventKind.subscriptionIntentRemoved,
          at: _clock.now(),
        ),
      );
      _unsubscribeChannelIfSent(channelName);
    }
    return removed;
  }

  

  void Function() on(String domain, String type, EventHandler handler) {
    return _eventDispatcher.on(domain, type, handler);
  }

  void Function() onUnknown(UnknownTypeHandler handler) {
    return _eventDispatcher.onUnknown(handler);
  }

  

  
  
  Map<String, PresenceMember> get presenceSnapshot =>
      Map.unmodifiable(_presenceMembers);

  void Function() onPresenceEvent(void Function(PresenceEvent event) handler) {
    _presenceListeners.add(handler);
    return () => _presenceListeners.remove(handler);
  }

  
  
  
  void Function() onActiveRoomChanged(
      void Function(RoomChannel? room) handler) {
    _activeRoomChangeListeners.add(handler);
    return () => _activeRoomChangeListeners.remove(handler);
  }

  void _emitPresenceEvent(PresenceEvent event) {
    for (final listener in _presenceListeners) {
      listener(event);
    }
  }

  void _notifyActiveRoomChanged(RoomChannel? room) {
    for (final listener in _activeRoomChangeListeners) {
      listener(room);
    }
  }

  

  
  
  
  
  
  
  
  
  
  Future<void> sendTypingSignal({
    required String type,
    required String actor,
    required DateTime expiresAt,
    Map<String, dynamic> extraPayload = const {},
    String? eventId,
  }) {
    final publisher = _ephemeralPublisher;
    final channel = _activeRoomChannel;
    final channelName = _activeRoomChannelName;
    final auth = _activeRoomAuth;
    final socketId = _socketId;
    if (publisher == null) {
      throw StateError('No EphemeralPublishPort configured on this client.');
    }
    if (channel == null || channelName == null || socketId == null) {
      throw StateError(
          'No active room subscription to send a typing signal for.');
    }
    if (auth == null) {
      throw StateError(
          'The active room\'s presence-channel authorization has not resolved yet.');
    }
    final envelope = <String, dynamic>{
      'version': 1,
      'id': eventId ?? generateEventId(),
      'kind': 'ephemeral',
      'domain': presenceDomain,
      'type': type,
      'tenant': channel.tenant,
      'occurred_at':
          DateTime.fromMillisecondsSinceEpoch(_clock.now(), isUtc: true)
              .toIso8601String(),
      'subject': {'type': 'room', 'id': channel.roomId},
      'expires_at': expiresAt.toUtc().toIso8601String(),
      'payload': {'actor': actor, ...extraPayload},
    };
    return publisher.publish(
      EphemeralPublishRequest(
        channelName: channelName,
        socketId: socketId,
        auth: auth.auth,
        channelData: auth.channelData ?? '',
        envelope: envelope,
      ),
    );
  }

  

  bool _isCurrentGeneration(int generation) => generation == _generation;

  
  
  
  
  void _emitRecovery(RecoveryReason reason) {
    final now = _clock.now();
    final myGeneration = _generation;
    _record(RecoveryRequestedTelemetryEvent(reason: reason, at: now));
    _recoveryCoordinator.onRecoveryNeeded(
      RecoveryContext(
        reason: reason,
        generation: myGeneration,
        occurredAt: now,
        isCurrentGeneration: () => _isCurrentGeneration(myGeneration),
      ),
    );
  }

  void _beginConnecting() {
    _generation++;
    final myGeneration = _generation;
    _pendingSubscriptions.clear();
    _sentSubscribeChannelsThisGeneration.clear();
    _socketId = null;
    _transitionTo(LifecycleState.connecting);

    _connection = _transport.connect(
      _bootstrap.socketUrl,
      _GenerationGuardedHandlers(
        isCurrentGeneration: () => _isCurrentGeneration(myGeneration),
        onOpen: () {},
        onMessage: _handleRawMessage,
        onCloseOrError: _handleTransportGone,
      ),
    );
  }

  
  
  
  
  void _handleTransportGone() {
    final pending = _pendingReconnectHandle;
    if (pending != null) {
      _scheduler.cancel(pending);
      _pendingReconnectHandle = null;
    }
    _connection = null;
    _wasUncertainDisconnect = true;
    _transitionTo(LifecycleState.disconnected);
    _scheduleReconnect();
  }

  void _scheduleReconnect() {
    final myGeneration = _generation;
    final random = _random;
    final delayMs = random == null
        ? computeBackoffDelayMs(_attempt, _backoffPolicy)
        : computeBackoffDelayMs(_attempt, _backoffPolicy, random: random);
    _attempt++;
    _record(ReconnectAttemptTelemetryEvent(
        attempt: _attempt, delayMs: delayMs, at: _clock.now()));
    _transitionTo(LifecycleState.reconnectWait);
    _pendingReconnectHandle = _scheduler.schedule(delayMs, () {
      if (!_isCurrentGeneration(myGeneration)) return;
      _pendingReconnectHandle = null;
      _beginConnecting();
    });
  }

  void _handleLifecycleSignal(LifecycleSignal signal) {
    if (signal.kind == LifecycleSignalKind.appBackground) {
      if (_state != LifecycleState.idle && _state != LifecycleState.stopped) {
        _wasBackgrounded = true;
      }
      return;
    }
    if (signal.kind != LifecycleSignalKind.networkOnline &&
        signal.kind != LifecycleSignalKind.appForeground) {
      return;
    }
    if (signal.kind == LifecycleSignalKind.appForeground &&
        _state == LifecycleState.connected &&
        _wasBackgrounded) {
      _wasBackgrounded = false;
      _emitRecovery(RecoveryReason.foregroundRestored);
      return;
    }
    if (_state != LifecycleState.reconnectWait) return;
    final pending = _pendingReconnectHandle;
    if (pending != null) {
      _scheduler.cancel(pending);
      _pendingReconnectHandle = null;
    }
    _beginConnecting();
  }

  

  void _maybeSubscribeNow() {
    if (_state != LifecycleState.connected &&
        _state != LifecycleState.subscribing) {
      return;
    }
    final newlyPending = _trySubscribeAll();
    if (newlyPending > 0 && _state == LifecycleState.connected) {
      _transitionTo(LifecycleState.subscribing);
    }
  }

  int _trySubscribeAll() {
    var count = 0;
    for (final intent in _intentRegistry.list()) {
      if (_sentSubscribeChannelsThisGeneration.contains(intent.channelName)) {
        continue;
      }
      _pendingSubscriptions.add(intent.channelName);
      count++;
      _subscribeIntent(intent);
    }
    return count;
  }

  void _subscribeIntent(SubscriptionIntent intent) {
    final myGeneration = _generation;
    _sentSubscribeChannelsThisGeneration.add(intent.channelName);
    _authCallback
        .authorize(
      AuthCallbackRequest(
        socketId: _socketId ?? '',
        channel: intent.channel,
        channelName: intent.channelName,
        isPresence: intent.kind == IntentKind.room,
      ),
    )
        .then((auth) {
      if (!_isCurrentGeneration(myGeneration)) return;
      if (intent.kind == IntentKind.room &&
          intent.channelName == _activeRoomChannelName) {
        _activeRoomAuth = auth;
      }
      _connection?.send(
        encodeOutgoingFrame('pusher:subscribe', {
          'channel': intent.channelName,
          'auth': auth.auth,
          if (auth.channelData != null) 'channel_data': auth.channelData,
        }),
      );
    }).catchError((Object _) {
      if (!_isCurrentGeneration(myGeneration)) return;
      _resolveSubscription(intent.channelName, false);
    });
  }

  void _unsubscribeChannelIfSent(String channelName) {
    final wasPending = _pendingSubscriptions.remove(channelName);
    final wasSent = _sentSubscribeChannelsThisGeneration.remove(channelName);
    if (wasSent) {
      _connection?.send(
          encodeOutgoingFrame('pusher:unsubscribe', {'channel': channelName}));
    }
    
    
    
    if (wasPending) _checkSubscribingDrained();
  }

  
  
  
  
  
  void _checkSubscribingDrained() {
    if (_pendingSubscriptions.isNotEmpty ||
        _state != LifecycleState.subscribing) {
      return;
    }
    if (_wasUncertainDisconnect) {
      _wasUncertainDisconnect = false;
      final now = _clock.now();
      final myGeneration = _generation;
      _transitionTo(LifecycleState.recovering);
      _record(RecoveryRequestedTelemetryEvent(
          reason: RecoveryReason.reconnectUncertain, at: now));
      _recoveryCoordinator.onRecoveryNeeded(
        RecoveryContext(
          reason: RecoveryReason.reconnectUncertain,
          generation: myGeneration,
          occurredAt: now,
          isCurrentGeneration: () => _isCurrentGeneration(myGeneration),
        ),
      );
      _transitionTo(LifecycleState.connected);
    } else {
      _transitionTo(LifecycleState.connected);
    }
  }

  
  
  
  
  
  
  void _resolveSubscription(String channelName, bool success) {
    if (!_pendingSubscriptions.contains(channelName)) return;
    _pendingSubscriptions.remove(channelName);
    _record(
      SubscriptionResultTelemetryEvent(
        kind: success
            ? TelemetryEventKind.subscriptionEstablished
            : TelemetryEventKind.subscriptionFailed,
        at: _clock.now(),
      ),
    );
    if (!success) {
      SubscriptionIntent? intent;
      for (final candidate in _intentRegistry.list()) {
        if (candidate.channelName == channelName) {
          intent = candidate;
          break;
        }
      }
      if (intent != null && intent.kind != IntentKind.room) {
        _emitRecovery(RecoveryReason.subscriptionLost);
      }
    }
    _checkSubscribingDrained();
  }

  
  
  
  
  void _onConnected() {
    _attempt = 0;
    _transitionTo(LifecycleState.connected);
    _transitionTo(LifecycleState.subscribing);
    _trySubscribeAll();
    _checkSubscribingDrained();
  }

  

  void _handleRawMessage(String raw) {
    final frame = parseIncomingFrame(raw);
    if (frame == null) return;
    if (isControlEvent(frame.event)) {
      _handleControlFrame(frame);
      return;
    }
    
    
    
    if (frame.event != applicationEnvelopeEvent) return;
    _handleApplicationFrame(frame);
  }

  void _handleControlFrame(IncomingFrame frame) {
    switch (frame.event) {
      case 'pusher:connection_established':
        final established = parseConnectionEstablished(frame.data);
        if (established == null) return;
        _socketId = established.socketId;
        if (_state == LifecycleState.connecting) _onConnected();
        return;
      case 'pusher:ping':
        _connection?.send(encodeOutgoingFrame('pusher:pong', {}));
        return;
      case 'pusher_internal:subscription_succeeded':
        final channel = frame.channel;
        if (channel != null) _resolveSubscription(channel, true);
        if (channel != null && channel == _activeRoomChannelName) {
          
          
          
          final hash = parsePresenceHash(frame.data);
          if (hash != null) {
            _presenceMembers
              ..clear()
              ..addAll(hash);
            _emitPresenceEvent(
                PresenceSnapshot(Map.unmodifiable(_presenceMembers)));
          }
        }
        return;
      case 'pusher_internal:member_added':
        _handlePresenceMemberEvent(frame, joined: true);
        return;
      case 'pusher_internal:member_removed':
        _handlePresenceMemberEvent(frame, joined: false);
        return;
      case 'pusher:subscription_error':
        final channel = frame.channel;
        if (channel != null) _resolveSubscription(channel, false);
        return;
      case 'pusher:error':
        
        
        
        
        
        
        for (final channelName in List<String>.from(_pendingSubscriptions)) {
          _resolveSubscription(channelName, false);
        }
        return;
      default:
        return;
    }
  }

  void _handlePresenceMemberEvent(IncomingFrame frame, {required bool joined}) {
    final channel = frame.channel;
    if (channel == null || channel != _activeRoomChannelName) return;
    final member = parseMemberEventData(frame.data);
    if (member == null) return;
    if (joined) {
      _presenceMembers[member.userId] = member;
      _emitPresenceEvent(PresenceMemberJoined(member));
    } else {
      _presenceMembers.remove(member.userId);
      _emitPresenceEvent(PresenceMemberLeft(member.userId));
    }
  }

  
  
  
  void _handleApplicationFrame(IncomingFrame frame) {
    final now = _clock.now();
    final decoded = _envelopeDecoder.decode(frame.data);
    if (decoded is DecodeFailed) {
      _record(EnvelopeDroppedTelemetryEvent(
          reason: EnvelopeDropReason.invalid, at: now));
      return;
    }
    final envelope = (decoded as DecodeOk).envelope;
    if (envelope.kind == EnvelopeKind.ephemeral) {
      final expiresAt = envelope.expiresAt;
      if (expiresAt != null && expiresAt.millisecondsSinceEpoch <= now) {
        _record(
          EnvelopeDroppedTelemetryEvent(
            reason: EnvelopeDropReason.expired,
            at: now,
          ),
        );
        return;
      }
    } else {
      if (_dedup.hasSeen(envelope.id, now)) {
        _record(
          EnvelopeDroppedTelemetryEvent(
            reason: EnvelopeDropReason.duplicate,
            at: now,
          ),
        );
        return;
      }
      _dedup.remember(envelope.id, now);
    }
    _record(
      EventDispatchedTelemetryEvent(
        envelopeKind: envelope.kind,
        at: now,
      ),
    );
    _eventDispatcher.dispatch(envelope);
  }

  

  void _transitionTo(LifecycleState next) {
    if (!isValidTransition(_state, next)) {
      throw StateError(
          'invalid lifecycle transition: ${_state.wireValue} -> ${next.wireValue}');
    }
    final previous = _state;
    _state = next;
    _record(StateTransitionTelemetryEvent(
        from: previous, to: next, at: _clock.now()));
    for (final listener in _stateListeners) {
      listener(previous, next);
    }
  }

  void _record(TelemetryEvent event) => _telemetry.record(event);
}




final class _GenerationGuardedHandlers implements SocketTransportHandlers {
  _GenerationGuardedHandlers({
    required this.isCurrentGeneration,
    required void Function() onOpen,
    required void Function(String data) onMessage,
    required void Function() onCloseOrError,
  })  : _onOpen = onOpen,
        _onMessage = onMessage,
        _onCloseOrError = onCloseOrError;

  final bool Function() isCurrentGeneration;
  final void Function() _onOpen;
  final void Function(String data) _onMessage;
  final void Function() _onCloseOrError;
  bool _transportGone = false;

  void _reportTransportGone() {
    if (!isCurrentGeneration() || _transportGone) return;
    _transportGone = true;
    _onCloseOrError();
  }

  @override
  void onOpen() {
    if (!isCurrentGeneration()) return;
    _onOpen();
  }

  @override
  void onMessage(String data) {
    if (!isCurrentGeneration()) return;
    _onMessage(data);
  }

  @override
  void onClose(TransportCloseEvent event) {
    _reportTransportGone();
  }

  @override
  void onError(Object error) {
    _reportTransportGone();
  }
}
