



library;

import '../envelope.dart';
import 'client.dart';
import 'ephemeral_event_types.dart';
import 'ports.dart';
import 'state.dart';









final class RoomTypingSender {
  RoomTypingSender({
    required RealtimeLifecycleClient client,
    required ClockPort clock,
    required SchedulerPort scheduler,
    required String actor,
    this.throttleInterval = const Duration(seconds: 3),
    this.inactivityTimeout = const Duration(seconds: 5),
    this.eventExpiry = const Duration(seconds: 8),
    String Function()? eventIdGenerator,
  })  : _client = client,
        _clock = clock,
        _scheduler = scheduler,
        _actor = actor,
        _eventIdGenerator = eventIdGenerator;

  final RealtimeLifecycleClient _client;
  final ClockPort _clock;
  final SchedulerPort _scheduler;
  final String _actor;
  final String Function()? _eventIdGenerator;

  
  
  final Duration throttleInterval;

  
  
  final Duration inactivityTimeout;

  
  
  final Duration eventExpiry;

  bool _started = false;
  int _lastStartedAtMs = 0;
  SchedulerHandle? _inactivityHandle;

  
  
  
  void notifyTyping() {
    final now = _clock.now();
    if (!_started ||
        (now - _lastStartedAtMs) >= throttleInterval.inMilliseconds) {
      _started = true;
      _lastStartedAtMs = now;
      _sendBestEffort(typingStartedType);
    }
    _rescheduleInactivityTimer();
  }

  
  
  void stopTyping() {
    _cancelInactivityTimer();
    if (!_started) return;
    _started = false;
    _sendBestEffort(typingStoppedType);
  }

  
  
  
  
  void dispose() {
    _cancelInactivityTimer();
    _started = false;
  }

  void _rescheduleInactivityTimer() {
    _cancelInactivityTimer();
    _inactivityHandle =
        _scheduler.schedule(inactivityTimeout.inMilliseconds, () {
      _inactivityHandle = null;
      stopTyping();
    });
  }

  void _cancelInactivityTimer() {
    final handle = _inactivityHandle;
    if (handle != null) {
      _scheduler.cancel(handle);
      _inactivityHandle = null;
    }
  }

  void _sendBestEffort(String type) {
    final expiresAt = DateTime.fromMillisecondsSinceEpoch(
        _clock.now() + eventExpiry.inMilliseconds,
        isUtc: true);
    
    
    
    
    Future<void>.sync(
      () => _client.sendTypingSignal(
        type: type,
        actor: _actor,
        expiresAt: expiresAt,
        eventId: _eventIdGenerator?.call(),
      ),
    ).catchError((Object _) {
      
    });
  }
}








final class TypingIndicatorTracker {
  TypingIndicatorTracker({
    required RealtimeLifecycleClient client,
    required ClockPort clock,
    required SchedulerPort scheduler,
    void Function(Set<String> typingActors)? onChange,
  })  : _clock = clock,
        _scheduler = scheduler,
        _onChange = onChange {
    _offStarted = client.on(presenceDomain, typingStartedType, _handleStarted);
    _offStopped = client.on(presenceDomain, typingStoppedType, _handleStopped);
    _offRoomChanged = client.onActiveRoomChanged((_) => clear());
    _offState = client.onStateChange((from, to) {
      if (to == LifecycleState.disconnected ||
          to == LifecycleState.reconnectWait) {
        clear();
      }
    });
  }

  final ClockPort _clock;
  final SchedulerPort _scheduler;
  final void Function(Set<String> typingActors)? _onChange;

  late final void Function() _offStarted;
  late final void Function() _offStopped;
  late final void Function() _offRoomChanged;
  late final void Function() _offState;

  final Map<String, SchedulerHandle> _expiryTimers = {};

  Set<String> get typingActors => _expiryTimers.keys.toSet();

  void _handleStarted(Envelope envelope) {
    final actor = envelope.payload['actor'];
    final expiresAt = envelope.expiresAt;
    if (actor is! String || actor.isEmpty || expiresAt == null) return;
    _scheduleExpiry(actor, expiresAt);
    _notify();
  }

  void _handleStopped(Envelope envelope) {
    final actor = envelope.payload['actor'];
    if (actor is! String || actor.isEmpty) return;
    if (_clearActor(actor)) _notify();
  }

  void _scheduleExpiry(String actor, DateTime expiresAt) {
    _cancelTimerFor(actor);
    final delayMs = expiresAt.millisecondsSinceEpoch - _clock.now();
    _expiryTimers[actor] = _scheduler.schedule(delayMs > 0 ? delayMs : 0, () {
      if (_clearActor(actor)) _notify();
    });
  }

  bool _clearActor(String actor) {
    final handle = _expiryTimers.remove(actor);
    if (handle == null) return false;
    _scheduler.cancel(handle);
    return true;
  }

  void _cancelTimerFor(String actor) {
    final handle = _expiryTimers.remove(actor);
    if (handle != null) _scheduler.cancel(handle);
  }

  
  
  void clear() {
    if (_expiryTimers.isEmpty) return;
    for (final handle in _expiryTimers.values) {
      _scheduler.cancel(handle);
    }
    _expiryTimers.clear();
    _notify();
  }

  void dispose() {
    clear();
    _offStarted();
    _offStopped();
    _offRoomChanged();
    _offState();
  }

  void _notify() => _onChange?.call(typingActors);
}
