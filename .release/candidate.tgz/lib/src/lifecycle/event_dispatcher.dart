import '../envelope.dart';
import 'ports.dart';

String _key(String domain, String type) => '$domain $type';




final class DomainEventDispatcher implements EventDispatcher {
  final Map<String, Set<EventHandler>> _handlers = {};
  final Set<UnknownTypeHandler> _unknownHandlers = {};

  @override
  void Function() on(String domain, String type, EventHandler handler) {
    final key = _key(domain, type);
    final set = _handlers.putIfAbsent(key, () => <EventHandler>{});
    set.add(handler);
    return () => set.remove(handler);
  }

  @override
  void Function() onUnknown(UnknownTypeHandler handler) {
    _unknownHandlers.add(handler);
    return () => _unknownHandlers.remove(handler);
  }

  @override
  void dispatch(Envelope envelope) {
    final set = _handlers[_key(envelope.domain, envelope.type)];
    if (set == null || set.isEmpty) {
      for (final unknown in _unknownHandlers) {
        unknown(envelope.domain, envelope.type);
      }
      return;
    }
    for (final handler in set) {
      handler(envelope);
    }
  }
}
