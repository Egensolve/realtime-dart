





library;

import 'dart:convert';

const int _maxFrameBytes = 65536;

bool _isBoundedFrame(String value) =>
    value.length <= _maxFrameBytes &&
    utf8.encode(value).length <= _maxFrameBytes;

final class IncomingFrame {
  const IncomingFrame({required this.event, this.channel, required this.data});

  final String event;
  final String? channel;

  
  final String data;
}


IncomingFrame? parseIncomingFrame(String raw) {
  if (!_isBoundedFrame(raw)) return null;
  Object? parsed;
  try {
    parsed = jsonDecode(raw);
  } on FormatException {
    return null;
  }
  if (parsed is! Map<String, dynamic>) return null;
  final event = parsed['event'];
  final data = parsed['data'];
  if (event is! String || data is! String) return null;
  final channel = parsed['channel'];
  return IncomingFrame(
      event: event, channel: channel is String ? channel : null, data: data);
}

bool isControlEvent(String event) {
  return event.startsWith('pusher:') || event.startsWith('pusher_internal:');
}





const String applicationEnvelopeEvent = 'v1.envelope';

final class ConnectionEstablished {
  const ConnectionEstablished({required this.socketId});

  final String socketId;
}


ConnectionEstablished? parseConnectionEstablished(String data) {
  if (!_isBoundedFrame(data)) return null;
  Object? parsed;
  try {
    parsed = jsonDecode(data);
  } on FormatException {
    return null;
  }
  if (parsed is! Map<String, dynamic>) return null;
  final socketId = parsed['socket_id'];
  if (socketId is! String) return null;
  return ConnectionEstablished(socketId: socketId);
}



String encodeOutgoingFrame(String event, Map<String, dynamic> data) {
  return jsonEncode({'event': event, 'data': data});
}
