import '../envelope_validator.dart';
import '../validation_error.dart';
import 'ports.dart';



final class ContractsEnvelopeDecoder implements EnvelopeDecoderPort {
  const ContractsEnvelopeDecoder();

  @override
  DecodeResult decode(String raw) {
    try {
      return DecodeOk(EnvelopeValidator.parse(raw));
    } on ValidationError catch (error) {
      return DecodeFailed(error);
    }
  }
}

const EnvelopeDecoderPort defaultEnvelopeDecoder = ContractsEnvelopeDecoder();
