import '../channel/channel.dart';
import 'ports.dart';




final class DefaultSubscriptionIntentRegistry
    implements SubscriptionIntentRegistry {
  final Map<String, SubscriptionIntent> _intents = {};
  String? _activeRoomChannelName;
  String? _activeCallChannelName;

  @override
  SubscriptionIntent addAccountIntent(AccountChannel channel) {
    final channelName = channel.toChannelString();
    final intent = SubscriptionIntent(
      kind: IntentKind.account,
      channel: channel,
      channelName: channelName,
    );
    _intents[channelName] = intent;
    return intent;
  }

  @override
  SubscriptionIntent addDeviceIntent(DeviceChannel channel) {
    final channelName = channel.toChannelString();
    final intent = SubscriptionIntent(
      kind: IntentKind.device,
      channel: channel,
      channelName: channelName,
    );
    _intents[channelName] = intent;
    return intent;
  }

  @override
  SubscriptionIntent? setActiveRoomIntent(RoomChannel? channel) {
    if (_activeRoomChannelName != null) {
      _intents.remove(_activeRoomChannelName);
      _activeRoomChannelName = null;
    }
    if (channel == null) return null;
    final channelName = channel.toChannelString();
    final intent = SubscriptionIntent(
      kind: IntentKind.room,
      channel: channel,
      channelName: channelName,
    );
    _intents[channelName] = intent;
    _activeRoomChannelName = channelName;
    return intent;
  }

  @override
  SubscriptionIntent? setActiveCallIntent(CallChannel? channel) {
    if (_activeCallChannelName != null) {
      _intents.remove(_activeCallChannelName);
      _activeCallChannelName = null;
    }
    if (channel == null) return null;
    final channelName = channel.toChannelString();
    final intent = SubscriptionIntent(
      kind: IntentKind.call,
      channel: channel,
      channelName: channelName,
    );
    _intents[channelName] = intent;
    _activeCallChannelName = channelName;
    return intent;
  }

  @override
  bool removeIntent(String channelName) {
    if (channelName == _activeRoomChannelName) {
      _activeRoomChannelName = null;
    }
    if (channelName == _activeCallChannelName) {
      _activeCallChannelName = null;
    }
    return _intents.remove(channelName) != null;
  }

  @override
  List<SubscriptionIntent> list() => _intents.values.toList();

  @override
  List<SubscriptionIntent> clear() {
    final removed = _intents.values.toList();
    _intents.clear();
    _activeRoomChannelName = null;
    _activeCallChannelName = null;
    return removed;
  }
}
