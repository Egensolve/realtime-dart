



library;



const String presenceDomain = 'presence';
const String typingStartedType = 'typing.started';
const String typingStoppedType = 'typing.stopped';
