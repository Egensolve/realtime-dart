












library;

import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:http/http.dart' as http;

import '../ports.dart';
import 'url_policy.dart';

typedef HeaderProvider = FutureOr<Map<String, String>> Function();

final class HttpAuthCallback implements AuthCallbackPort {
  HttpAuthCallback({
    required this.authEndpoint,
    http.Client? client,
    this.headerProvider,
  })  : _endpoint = requireSecureEndpoint(authEndpoint, const {'https'}),
        _client = client ?? http.Client();

  static const int _maxResponseBytes = 8192;

  final String authEndpoint;
  final HeaderProvider? headerProvider;
  final Uri _endpoint;
  final http.Client _client;

  @override
  Future<AuthCallbackResponse> authorize(AuthCallbackRequest request) async {
    final extraHeaders = await (headerProvider?.call() ??
        Future.value(const <String, String>{}));
    final body = jsonEncode({
      'socket_id': request.socketId,
      'channel_name': request.channelName,
    });

    final outgoing = http.Request('POST', _endpoint)
      ..headers.addAll({'content-type': 'application/json', ...extraHeaders})
      ..body = body;
    final response = await _client.send(outgoing);
    final responseBody = await _readBoundedBody(response);

    if (response.statusCode < 200 || response.statusCode >= 300) {
      
      
      throw StateError(
          'auth callback rejected subscription (HTTP ${response.statusCode})');
    }

    final decoded = jsonDecode(responseBody);
    if (decoded is! Map<String, dynamic> || decoded['auth'] is! String) {
      throw StateError('auth callback returned a malformed response');
    }
    final channelData = decoded['channel_data'];
    return AuthCallbackResponse(
      auth: decoded['auth'] as String,
      channelData: channelData is String ? channelData : null,
    );
  }

  static Future<String> _readBoundedBody(http.StreamedResponse response) async {
    final bytes = BytesBuilder(copy: false);
    var length = 0;
    await for (final chunk in response.stream) {
      length += chunk.length;
      if (length > _maxResponseBytes) {
        throw StateError('auth callback response exceeded the size limit');
      }
      bytes.add(chunk);
    }
    return utf8.decode(bytes.takeBytes());
  }
}
