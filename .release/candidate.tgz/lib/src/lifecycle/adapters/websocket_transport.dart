



library;

import 'dart:async';
import 'dart:convert';

import 'package:web_socket_channel/io.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

import '../ports.dart';
import 'url_policy.dart';

typedef WebSocketChannelFactory = WebSocketChannel Function(
  Uri url, {
  Map<String, dynamic>? headers,
});

WebSocketChannel _defaultConnect(Uri url, {Map<String, dynamic>? headers}) {
  return IOWebSocketChannel.connect(url, headers: headers);
}















final class WebSocketTransport implements SocketTransportPort {
  WebSocketTransport(
      {Map<String, dynamic>? headers, WebSocketChannelFactory? channelFactory})
      : _headers = headers,
        _channelFactory = channelFactory ?? _defaultConnect;

  final Map<String, dynamic>? _headers;
  final WebSocketChannelFactory _channelFactory;

  static const int _maxIncomingFrameBytes = 65536;

  @override
  SocketConnection connect(String url, SocketTransportHandlers handlers) {
    final channel = _channelFactory(
      requireSecureEndpoint(url, const {'wss'}),
      headers: _headers,
    );

    unawaited(channel.ready.then(
      (_) => handlers.onOpen(),
      onError: (Object error) => handlers.onError(error),
    ));

    channel.stream.listen(
      (Object? data) {
        final String message;
        if (data is String) {
          if (data.length > _maxIncomingFrameBytes ||
              utf8.encode(data).length > _maxIncomingFrameBytes) {
            handlers.onError(
                StateError('incoming realtime frame exceeded the size limit'));
            unawaited(channel.sink.close(4009, 'frame too large'));
            return;
          }
          message = data;
        } else if (data is List<int>) {
          if (data.length > _maxIncomingFrameBytes) {
            handlers.onError(
                StateError('incoming realtime frame exceeded the size limit'));
            unawaited(channel.sink.close(4009, 'frame too large'));
            return;
          }
          message = utf8.decode(data);
        } else {
          handlers.onError(
              StateError('incoming realtime frame has an unsupported type'));
          return;
        }
        handlers.onMessage(message);
      },
      onError: (Object error) => handlers.onError(error),
      onDone: () {
        final closeCode = channel.closeCode ?? 1006;
        final closeReason = channel.closeReason ?? '';
        handlers.onClose(TransportCloseEvent(
          code: closeCode,
          reason: closeReason,
          wasClean: closeCode == 1000,
        ));
      },
      cancelOnError: false,
    );

    return _WebSocketConnectionAdapter(channel);
  }
}

final class _WebSocketConnectionAdapter implements SocketConnection {
  _WebSocketConnectionAdapter(this._channel);

  final WebSocketChannel _channel;

  @override
  void send(String data) => _channel.sink.add(data);

  @override
  void close({int? code, String? reason}) {
    _channel.sink.close(code, reason);
  }
}
