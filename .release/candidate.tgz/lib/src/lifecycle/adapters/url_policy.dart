Uri requireSecureEndpoint(String value, Set<String> secureSchemes) {
  final uri = Uri.parse(value);
  if (!uri.hasScheme || uri.host.isEmpty || uri.userInfo.isNotEmpty) {
    throw ArgumentError.value(
        value, 'endpoint', 'must be an absolute URL without credentials');
  }

  final loopback =
      uri.host == 'localhost' || uri.host == '127.0.0.1' || uri.host == '::1';
  final developmentScheme = secureSchemes.contains('https') ? 'http' : 'ws';
  if (!secureSchemes.contains(uri.scheme) &&
      !(loopback && uri.scheme == developmentScheme)) {
    throw ArgumentError.value(
      value,
      'endpoint',
      'must use a secure scheme except for loopback development hosts',
    );
  }

  return uri;
}
