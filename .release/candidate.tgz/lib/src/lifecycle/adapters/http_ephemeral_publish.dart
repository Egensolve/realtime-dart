








library;

import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

import '../ports.dart';
import 'url_policy.dart';

typedef EphemeralPublishHeaderProvider = FutureOr<Map<String, String>>
    Function();

final class HttpEphemeralPublishCallback implements EphemeralPublishPort {
  HttpEphemeralPublishCallback({
    required this.endpoint,
    http.Client? client,
    this.headerProvider,
  })  : _endpoint = requireSecureEndpoint(endpoint, const {'https'}),
        _client = client ?? http.Client();

  static const int _maxResponseBytes = 8192;

  
  final String endpoint;
  final EphemeralPublishHeaderProvider? headerProvider;
  final Uri _endpoint;
  final http.Client _client;

  @override
  Future<void> publish(EphemeralPublishRequest request) async {
    final extraHeaders = await (headerProvider?.call() ??
        Future.value(const <String, String>{}));
    final body = jsonEncode({
      'channel': request.channelName,
      'socket_id': request.socketId,
      'auth': request.auth,
      'channel_data': request.channelData,
      'envelope': request.envelope,
    });

    final outgoing = http.Request('POST', _endpoint)
      ..headers.addAll({'content-type': 'application/json', ...extraHeaders})
      ..body = body;
    final response = await _client.send(outgoing);
    var responseBytes = 0;
    await for (final chunk in response.stream) {
      responseBytes += chunk.length;
      if (responseBytes > _maxResponseBytes) {
        throw StateError('ephemeral event response exceeded the size limit');
      }
    }

    if (response.statusCode < 200 || response.statusCode >= 300) {
      
      
      throw StateError(
          'ephemeral event relay rejected the request (HTTP ${response.statusCode})');
    }
  }
}
