import 'dart:async';

import '../ports.dart';
import '../backoff.dart';

const BackoffPolicy _defaultRetryBackoff =
    BackoffPolicy(baseDelayMs: 1000, maxDelayMs: 30000);
const int _defaultMaxAttempts = 5;

final class RecoveryScopeBinding {
  const RecoveryScopeBinding({required this.scope, required this.handler});

  final RecoveryScope scope;
  final RecoveryHandler handler;
}

final class _NoopTelemetrySink implements TelemetrySinkPort {
  const _NoopTelemetrySink();

  @override
  void record(TelemetryEvent event) {}
}

final class _ScopeState {
  bool inFlight = false;
  RecoveryContext? pendingContext;
  SchedulerHandle? retryHandle;
}









final class DefaultRecoveryCoordinator implements RecoveryCoordinatorPort {
  DefaultRecoveryCoordinator({
    required List<RecoveryScopeBinding> scopes,
    required CursorStorePort cursorStore,
    required ClockPort clock,
    required SchedulerPort scheduler,
    TelemetrySinkPort telemetry = const _NoopTelemetrySink(),
    BackoffPolicy retryBackoff = _defaultRetryBackoff,
    int maxAttempts = _defaultMaxAttempts,
    RandomSource? random,
  })  : _scopes = scopes,
        _cursorStore = cursorStore,
        _clock = clock,
        _scheduler = scheduler,
        _telemetry = telemetry,
        _retryBackoff = retryBackoff,
        _maxAttempts = maxAttempts,
        _random = random;

  final List<RecoveryScopeBinding> _scopes;
  final CursorStorePort _cursorStore;
  final ClockPort _clock;
  final SchedulerPort _scheduler;
  final TelemetrySinkPort _telemetry;
  final BackoffPolicy _retryBackoff;
  final int _maxAttempts;
  final RandomSource? _random;
  final Map<String, _ScopeState> _states = {};

  @override
  void onRecoveryNeeded(RecoveryContext context) {
    for (final binding in _scopes) {
      _triggerScope(binding, context);
    }
  }

  
  
  
  
  void reset() {
    for (final state in _states.values) {
      final handle = state.retryHandle;
      if (handle != null) _scheduler.cancel(handle);
    }
    _states.clear();
  }

  
  
  Future<void> forgetCursors() async {
    await Future.wait(
      _scopes.map((binding) => _cursorStore.clearCursor(binding.scope)),
    );
  }

  _ScopeState _getState(String scope) {
    return _states.putIfAbsent(scope, () => _ScopeState());
  }

  
  
  
  void _triggerScope(RecoveryScopeBinding binding, RecoveryContext context) {
    final state = _getState(binding.scope);
    if (state.inFlight) {
      state.pendingContext = context;
      return;
    }
    state.inFlight = true;
    unawaited(_runScope(binding, state, context, 0));
  }

  Future<void> _runScope(
    RecoveryScopeBinding binding,
    _ScopeState state,
    RecoveryContext context,
    int attempt,
  ) async {
    if (!context.isCurrentGeneration()) {
      _record(RecoverySupersededTelemetryEvent(at: _clock.now()));
      _finishScope(binding, state);
      return;
    }

    String? cursor;
    try {
      cursor = await _cursorStore.getCursor(binding.scope);
    } catch (_) {
      _record(CursorCorruptedTelemetryEvent(at: _clock.now()));
      cursor = null;
    }

    RecoveryApplyResult result;
    try {
      result = await binding.handler.apply(RecoveryApplyRequest(
        scope: binding.scope,
        cursor: cursor,
        reason: context.reason,
      ));
    } catch (_) {
      result = const RecoveryApplyResult(applied: false);
    }

    if (!context.isCurrentGeneration()) {
      _record(RecoverySupersededTelemetryEvent(at: _clock.now()));
      _finishScope(binding, state);
      return;
    }

    if (result.applied) {
      final newCursor = result.cursor;
      if (newCursor != null) {
        await _cursorStore.saveCursor(binding.scope, newCursor);
      }
      _record(RecoveryAppliedTelemetryEvent(
        reason: context.reason,
        at: _clock.now(),
      ));
      _finishScope(binding, state);
      return;
    }

    _record(RecoveryApplyFailedTelemetryEvent(
      reason: context.reason,
      attempt: attempt,
      at: _clock.now(),
    ));
    if (attempt + 1 >= _maxAttempts) {
      _finishScope(binding, state);
      return;
    }
    final random = _random;
    final delayMs = random == null
        ? computeBackoffDelayMs(attempt, _retryBackoff)
        : computeBackoffDelayMs(attempt, _retryBackoff, random: random);
    state.retryHandle = _scheduler.schedule(delayMs, () {
      state.retryHandle = null;
      unawaited(_runScope(binding, state, context, attempt + 1));
    });
  }

  void _finishScope(RecoveryScopeBinding binding, _ScopeState state) {
    state.inFlight = false;
    final next = state.pendingContext;
    state.pendingContext = null;
    if (next != null) {
      state.inFlight = true;
      unawaited(_runScope(binding, state, next, 0));
    }
  }

  void _record(TelemetryEvent event) {
    _telemetry.record(event);
  }
}
