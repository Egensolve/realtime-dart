




library;

import 'dart:convert';

const int _maxPresenceFrameBytes = 65536;

bool _isBoundedPresenceFrame(String value) =>
    value.length <= _maxPresenceFrameBytes &&
    utf8.encode(value).length <= _maxPresenceFrameBytes;





final class PresenceMember {
  const PresenceMember({required this.userId, required this.userInfo});

  final String userId;
  final Map<String, dynamic> userInfo;
}






sealed class PresenceEvent {
  const PresenceEvent();
}

final class PresenceSnapshot extends PresenceEvent {
  const PresenceSnapshot(this.members);

  
  final Map<String, PresenceMember> members;
}

final class PresenceMemberJoined extends PresenceEvent {
  const PresenceMemberJoined(this.member);

  final PresenceMember member;
}

final class PresenceMemberLeft extends PresenceEvent {
  const PresenceMemberLeft(this.userId);

  final String userId;
}





Map<String, PresenceMember>? parsePresenceHash(String data) {
  if (!_isBoundedPresenceFrame(data)) return null;
  Object? parsed;
  try {
    parsed = jsonDecode(data);
  } on FormatException {
    return null;
  }
  if (parsed is! Map<String, dynamic>) return null;
  final presence = parsed['presence'];
  if (presence is! Map<String, dynamic>) return null;
  final hash = presence['hash'];
  if (hash is! Map<String, dynamic>) return null;

  final members = <String, PresenceMember>{};
  for (final entry in hash.entries) {
    final userInfo = entry.value;
    members[entry.key] = PresenceMember(
      userId: entry.key,
      userInfo: userInfo is Map<String, dynamic> ? userInfo : const {},
    );
  }
  return members;
}




PresenceMember? parseMemberEventData(String data) {
  if (!_isBoundedPresenceFrame(data)) return null;
  Object? parsed;
  try {
    parsed = jsonDecode(data);
  } on FormatException {
    return null;
  }
  if (parsed is! Map<String, dynamic>) return null;
  final userId = parsed['user_id'];
  if (userId is! String || userId.isEmpty) return null;
  final userInfo = parsed['user_info'];
  return PresenceMember(
    userId: userId,
    userInfo: userInfo is Map<String, dynamic> ? userInfo : const {},
  );
}
