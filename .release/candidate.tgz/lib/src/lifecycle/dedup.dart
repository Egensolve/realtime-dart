import 'dart:collection';

import 'ports.dart';

final class _Entry {
  const _Entry(this.id, this.seenAt);

  final String id;
  final int seenAt;
}




final class BoundedDurableEventDeduplicator
    implements DurableEventDeduplicator {
  BoundedDurableEventDeduplicator(this._policy);

  final DedupPolicy _policy;
  final Queue<_Entry> _order = Queue<_Entry>();
  final Set<String> _index = <String>{};

  @override
  bool hasSeen(String id, int now) {
    prune(now);
    return _index.contains(id);
  }

  @override
  void remember(String id, int now) {
    prune(now);
    if (_index.contains(id)) return;
    if (_order.length >= _policy.maxEntries) {
      final oldest = _order.removeFirst();
      _index.remove(oldest.id);
    }
    _order.addLast(_Entry(id, now));
    _index.add(id);
  }

  @override
  void prune(int now) {
    while (_order.isNotEmpty && now - _order.first.seenAt > _policy.maxAgeMs) {
      final stale = _order.removeFirst();
      _index.remove(stale.id);
    }
  }

  @override
  void clear() {
    _order.clear();
    _index.clear();
  }

  @override
  int get size => _order.length;
}
