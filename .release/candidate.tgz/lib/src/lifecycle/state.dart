


enum LifecycleState {
  idle('idle'),
  connecting('connecting'),
  connected('connected'),
  subscribing('subscribing'),
  disconnected('disconnected'),
  reconnectWait('reconnect-wait'),
  recovering('recovering'),
  stopped('stopped');

  const LifecycleState(this.wireValue);

  final String wireValue;
}




final Map<LifecycleState, Set<LifecycleState>> validTransitions = {
  LifecycleState.idle: {LifecycleState.connecting},
  LifecycleState.stopped: {LifecycleState.connecting},
  LifecycleState.connecting: {
    LifecycleState.connected,
    LifecycleState.disconnected,
    LifecycleState.stopped,
  },
  LifecycleState.connected: {
    LifecycleState.subscribing,
    LifecycleState.disconnected,
    LifecycleState.stopped,
  },
  LifecycleState.subscribing: {
    LifecycleState.connected,
    LifecycleState.recovering,
    LifecycleState.disconnected,
    LifecycleState.stopped,
  },
  LifecycleState.recovering: {LifecycleState.connected, LifecycleState.stopped},
  LifecycleState.disconnected: {
    LifecycleState.reconnectWait,
    LifecycleState.stopped,
  },
  LifecycleState.reconnectWait: {
    LifecycleState.connecting,
    LifecycleState.stopped,
  },
};

bool isValidTransition(LifecycleState from, LifecycleState to) {
  return validTransitions[from]?.contains(to) ?? false;
}
