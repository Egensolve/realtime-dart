import 'dart:math' as math;

import 'ports.dart';



typedef RandomSource = double Function();

const int _maxExponent = 30;

final math.Random _sharedRandom = math.Random();



double _defaultRandom() => _sharedRandom.nextDouble();



int computeBackoffDelayMs(
  int attempt,
  BackoffPolicy policy, {
  RandomSource random = _defaultRandom,
}) {
  final exponent = attempt.clamp(0, _maxExponent);
  final cap = math.min(
    policy.maxDelayMs,
    (policy.baseDelayMs * math.pow(2, exponent)).toInt(),
  );
  return (random() * cap).floor();
}
