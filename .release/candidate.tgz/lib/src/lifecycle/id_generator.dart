







library;

import 'dart:math';

const String _crockfordBase32Alphabet = '0123456789ABCDEFGHJKMNPQRSTVWXYZ';



typedef IdGenerator = String Function();

String generateEventId([Random? random]) {
  final source = random ?? Random.secure();
  final buffer = StringBuffer();
  for (var i = 0; i < 26; i++) {
    buffer.write(_crockfordBase32Alphabet[source.nextInt(32)]);
  }
  return buffer.toString();
}
