



















library;

import '../channel/channel.dart';
import '../envelope.dart';
import '../validation_error.dart';
import 'state.dart';





final class TransportCloseEvent {
  const TransportCloseEvent({
    required this.code,
    required this.reason,
    required this.wasClean,
  });

  final int code;
  final String reason;
  final bool wasClean;
}

abstract interface class SocketTransportHandlers {
  void onOpen();
  void onMessage(String data);
  void onClose(TransportCloseEvent event);
  void onError(Object error);
}

abstract interface class SocketConnection {
  void send(String data);
  void close({int? code, String? reason});
}





abstract interface class SocketTransportPort {
  SocketConnection connect(String url, SocketTransportHandlers handlers);
}





abstract interface class ClockPort {
  
  int now();
}


abstract interface class SchedulerHandle {}

abstract interface class SchedulerPort {
  SchedulerHandle schedule(int delayMs, void Function() callback);
  void cancel(SchedulerHandle handle);
}





enum LifecycleSignalKind {
  networkOnline,
  networkOffline,
  appForeground,
  appBackground
}

final class LifecycleSignal {
  const LifecycleSignal(this.kind);

  final LifecycleSignalKind kind;
}




abstract interface class LifecycleSignalSource {
  
  void Function() subscribe(void Function(LifecycleSignal signal) listener);
}







final class LifecycleBootstrapConfig {
  const LifecycleBootstrapConfig(
      {required this.socketUrl, required this.tenant});

  final String socketUrl;
  final String tenant;
}

final class BackoffPolicy {
  const BackoffPolicy({required this.baseDelayMs, required this.maxDelayMs});

  final int baseDelayMs;
  final int maxDelayMs;
}

final class DedupPolicy {
  const DedupPolicy({required this.maxEntries, required this.maxAgeMs});

  final int maxEntries;
  final int maxAgeMs;
}





final class AuthCallbackRequest {
  const AuthCallbackRequest({
    required this.socketId,
    required this.channel,
    required this.channelName,
    required this.isPresence,
  });

  final String socketId;
  final Channel channel;
  final String channelName;
  final bool isPresence;
}


final class AuthCallbackResponse {
  const AuthCallbackResponse({required this.auth, this.channelData});

  final String auth;
  final String? channelData;
}




abstract interface class AuthCallbackPort {
  Future<AuthCallbackResponse> authorize(AuthCallbackRequest request);
}









final class EphemeralPublishRequest {
  const EphemeralPublishRequest({
    required this.channelName,
    required this.socketId,
    required this.auth,
    required this.channelData,
    required this.envelope,
  });

  final String channelName;
  final String socketId;
  final String auth;
  final String channelData;

  
  
  final Map<String, dynamic> envelope;
}




abstract interface class EphemeralPublishPort {
  Future<void> publish(EphemeralPublishRequest request);
}








enum RecoveryReason {
  reconnectUncertain('reconnect-uncertain'),
  subscriptionLost('subscription-lost'),
  foregroundRestored('foreground-restored'),
  sessionChanged('session-changed'),
  manual('manual');

  const RecoveryReason(this.wireValue);

  final String wireValue;
}

final class RecoveryContext {
  const RecoveryContext({
    required this.reason,
    required this.generation,
    required this.occurredAt,
    required this.isCurrentGeneration,
  });

  final RecoveryReason reason;
  final int generation;
  final int occurredAt;

  
  
  
  
  
  final bool Function() isCurrentGeneration;
}






abstract interface class RecoveryCoordinatorPort {
  void onRecoveryNeeded(RecoveryContext context);
}



typedef RecoveryScope = String;

final class RecoveryApplyRequest {
  const RecoveryApplyRequest({
    required this.scope,
    required this.cursor,
    required this.reason,
  });

  final RecoveryScope scope;

  
  final String? cursor;
  final RecoveryReason reason;
}

final class RecoveryApplyResult {
  const RecoveryApplyResult({required this.applied, this.cursor});

  
  final bool applied;

  
  
  final String? cursor;
}





abstract interface class RecoveryHandler {
  Future<RecoveryApplyResult> apply(RecoveryApplyRequest request);
}





enum EnvelopeDropReason {
  invalid('invalid'),
  duplicate('duplicate'),
  expired('expired');

  const EnvelopeDropReason(this.wireValue);

  final String wireValue;
}

enum TelemetryEventKind {
  stateTransition('state-transition'),
  reconnectAttempt('reconnect-attempt'),
  envelopeDropped('envelope-dropped'),
  eventDispatched('event-dispatched'),
  unknownTypeIgnored('unknown-type-ignored'),
  recoveryRequested('recovery-requested'),
  subscriptionIntentAdded('subscription-intent-added'),
  subscriptionIntentRemoved('subscription-intent-removed'),
  subscriptionEstablished('subscription-established'),
  subscriptionFailed('subscription-failed'),
  recoveryApplied('recovery-applied'),
  recoveryApplyFailed('recovery-apply-failed'),
  recoverySuperseded('recovery-superseded'),
  cursorCorrupted('cursor-corrupted'),
  sessionReset('session-reset');

  const TelemetryEventKind(this.wireValue);

  final String wireValue;
}




sealed class TelemetryEvent {
  const TelemetryEvent({required this.at});

  final int at;

  TelemetryEventKind get kind;
}

final class StateTransitionTelemetryEvent extends TelemetryEvent {
  const StateTransitionTelemetryEvent({
    required this.from,
    required this.to,
    required super.at,
  });

  final LifecycleState from;
  final LifecycleState to;

  @override
  TelemetryEventKind get kind => TelemetryEventKind.stateTransition;
}

final class ReconnectAttemptTelemetryEvent extends TelemetryEvent {
  const ReconnectAttemptTelemetryEvent({
    required this.attempt,
    required this.delayMs,
    required super.at,
  });

  final int attempt;
  final int delayMs;

  @override
  TelemetryEventKind get kind => TelemetryEventKind.reconnectAttempt;
}

final class EnvelopeDroppedTelemetryEvent extends TelemetryEvent {
  const EnvelopeDroppedTelemetryEvent({
    required this.reason,
    required super.at,
  });

  final EnvelopeDropReason reason;

  @override
  TelemetryEventKind get kind => TelemetryEventKind.envelopeDropped;
}

final class EventDispatchedTelemetryEvent extends TelemetryEvent {
  const EventDispatchedTelemetryEvent({
    required this.envelopeKind,
    required super.at,
  });

  final EnvelopeKind envelopeKind;

  @override
  TelemetryEventKind get kind => TelemetryEventKind.eventDispatched;
}

final class UnknownTypeIgnoredTelemetryEvent extends TelemetryEvent {
  const UnknownTypeIgnoredTelemetryEvent({required super.at});

  @override
  TelemetryEventKind get kind => TelemetryEventKind.unknownTypeIgnored;
}

final class RecoveryRequestedTelemetryEvent extends TelemetryEvent {
  const RecoveryRequestedTelemetryEvent({
    required this.reason,
    required super.at,
  });

  final RecoveryReason reason;

  @override
  TelemetryEventKind get kind => TelemetryEventKind.recoveryRequested;
}

final class SubscriptionIntentTelemetryEvent extends TelemetryEvent {
  const SubscriptionIntentTelemetryEvent({
    required this.kind,
    required super.at,
  }) : assert(
          kind == TelemetryEventKind.subscriptionIntentAdded ||
              kind == TelemetryEventKind.subscriptionIntentRemoved,
        );

  @override
  final TelemetryEventKind kind;
}

final class SubscriptionResultTelemetryEvent extends TelemetryEvent {
  const SubscriptionResultTelemetryEvent({
    required this.kind,
    required super.at,
  }) : assert(
          kind == TelemetryEventKind.subscriptionEstablished ||
              kind == TelemetryEventKind.subscriptionFailed,
        );

  @override
  final TelemetryEventKind kind;
}

final class RecoveryAppliedTelemetryEvent extends TelemetryEvent {
  const RecoveryAppliedTelemetryEvent({
    required this.reason,
    required super.at,
  });

  final RecoveryReason reason;

  @override
  TelemetryEventKind get kind => TelemetryEventKind.recoveryApplied;
}

final class RecoveryApplyFailedTelemetryEvent extends TelemetryEvent {
  const RecoveryApplyFailedTelemetryEvent({
    required this.reason,
    required this.attempt,
    required super.at,
  });

  final RecoveryReason reason;
  final int attempt;

  @override
  TelemetryEventKind get kind => TelemetryEventKind.recoveryApplyFailed;
}

final class RecoverySupersededTelemetryEvent extends TelemetryEvent {
  const RecoverySupersededTelemetryEvent({required super.at});

  @override
  TelemetryEventKind get kind => TelemetryEventKind.recoverySuperseded;
}

final class CursorCorruptedTelemetryEvent extends TelemetryEvent {
  const CursorCorruptedTelemetryEvent({required super.at});

  @override
  TelemetryEventKind get kind => TelemetryEventKind.cursorCorrupted;
}

final class SessionResetTelemetryEvent extends TelemetryEvent {
  const SessionResetTelemetryEvent({required super.at});

  @override
  TelemetryEventKind get kind => TelemetryEventKind.sessionReset;
}

abstract interface class TelemetrySinkPort {
  void record(TelemetryEvent event);
}








abstract interface class CursorStorePort {
  Future<String?> getCursor(String scope);
  Future<void> saveCursor(String scope, String cursor);

  
  
  
  
  
  
  Future<void> clearCursor(String scope);
}

final class OutgoingMessageRecord {
  const OutgoingMessageRecord({
    required this.id,
    required this.createdAt,
    required this.payload,
  });

  final String id;
  final int createdAt;
  final Map<String, dynamic> payload;
}




abstract interface class OutgoingMessageOutboxPort {
  Future<void> enqueue(OutgoingMessageRecord message);
}





enum IntentKind { account, device, room }

final class SubscriptionIntent {
  const SubscriptionIntent({
    required this.kind,
    required this.channel,
    required this.channelName,
  });

  final IntentKind kind;
  final Channel channel;
  final String channelName;
}





abstract interface class SubscriptionIntentRegistry {
  SubscriptionIntent addAccountIntent(AccountChannel channel);
  SubscriptionIntent addDeviceIntent(DeviceChannel channel);

  
  SubscriptionIntent? setActiveRoomIntent(RoomChannel? channel);
  bool removeIntent(String channelName);
  List<SubscriptionIntent> list();

  
  List<SubscriptionIntent> clear();
}






abstract interface class DurableEventDeduplicator {
  bool hasSeen(String id, int now);
  void remember(String id, int now);

  
  void prune(int now);

  
  void clear();
  int get size;
}





sealed class DecodeResult {
  const DecodeResult();
}

final class DecodeOk extends DecodeResult {
  const DecodeOk(this.envelope);

  final Envelope envelope;
}

final class DecodeFailed extends DecodeResult {
  const DecodeFailed(this.error);

  final ValidationError error;
}




abstract interface class EnvelopeDecoderPort {
  DecodeResult decode(String raw);
}





typedef EventHandler = void Function(Envelope envelope);
typedef UnknownTypeHandler = void Function(String domain, String type);


abstract interface class EventDispatcher {
  void Function() on(String domain, String type, EventHandler handler);
  void Function() onUnknown(UnknownTypeHandler handler);
  void dispatch(Envelope envelope);
}
