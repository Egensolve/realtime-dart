library;

import '../http/transport.dart';


final class IntelligenceClient {
  IntelligenceClient(
      {required String baseUrl,
      required String machineCredential,
      ApiTransport? transport,
      Duration timeout = const Duration(seconds: 5)})
      : _http = JsonApiClient(
            baseUrl: baseUrl,
            machineCredential: machineCredential,
            transport: transport,
            timeout: timeout);
  final JsonApiClient _http;

  Future<ApiResponse> profiles() =>
      _http.request('GET', "/api/v1/intelligence/profiles");

  Future<ApiResponse> createJob(
          Map<String, Object?> request, String idempotencyKey) =>
      _http.request('POST', "/api/v1/intelligence/jobs",
          payload: versioned(request, 'Intelligence'),
          idempotencyKey: idempotencyKey);

  Future<ApiResponse> job(String jobId) => _http.request(
      'GET', "/api/v1/intelligence/jobs/${apiResourceId(jobId, 'jobId')}");

  Future<ApiResponse> cancelJob(String jobId, String idempotencyKey) =>
      _http.request('POST',
          "/api/v1/intelligence/jobs/${apiResourceId(jobId, 'jobId')}/cancel",
          payload: const {'version': 1}, idempotencyKey: idempotencyKey);

  Future<ApiResponse> createInstructionSet(
          Map<String, Object?> request, String idempotencyKey) =>
      _http.request('POST', "/api/v1/intelligence/instruction-sets",
          payload: versioned(request, 'Intelligence'),
          idempotencyKey: idempotencyKey);

  Future<ApiResponse> addInstructionRevision(
          String setId, Map<String, Object?> request, String idempotencyKey) =>
      _http.request('POST',
          "/api/v1/intelligence/instruction-sets/${apiResourceId(setId, 'setId')}/revisions",
          payload: versioned(request, 'Intelligence'),
          idempotencyKey: idempotencyKey);

  Future<ApiResponse> instructionSet(String setId) => _http.request('GET',
      "/api/v1/intelligence/instruction-sets/${apiResourceId(setId, 'setId')}");
}
