library;

import '../http/transport.dart';

final class MediaClient {
  MediaClient({
    required String baseUrl,
    required String machineCredential,
    ApiTransport? transport,
    Duration timeout = const Duration(seconds: 5),
  }) : _http = JsonApiClient(
          baseUrl: baseUrl,
          machineCredential: machineCredential,
          transport: transport,
          timeout: timeout,
        );

  final JsonApiClient _http;

  Future<ApiResponse> createUploadIntent(
    Map<String, Object?> intent,
    String idempotencyKey,
  ) =>
      _http.request(
        'POST',
        '/api/v1/media/assets/upload-intents',
        payload: versioned(intent, 'Media'),
        idempotencyKey: idempotencyKey,
      );

  Future<ApiResponse> policy() => _http.request('GET', '/api/v1/media/policy');

  Future<ApiResponse> asset(String assetId) => _http.request(
        'GET',
        '/api/v1/media/assets/${apiResourceId(assetId, 'assetId')}',
      );

  Future<ApiResponse> createMultipartPartIntent(
    String assetId,
    int partNumber,
    Map<String, Object?> part,
    String idempotencyKey,
  ) {
    if (partNumber < 1 || partNumber > 10000) {
      throw ArgumentError.value(partNumber, 'partNumber', 'must be 1–10000');
    }
    return _http.request(
      'POST',
      '/api/v1/media/assets/${apiResourceId(assetId, 'assetId')}/multipart-parts/$partNumber/intent',
      payload: versioned(part, 'Media'),
      idempotencyKey: idempotencyKey,
    );
  }

  Future<ApiResponse> completeUpload(
    String assetId,
    Map<String, Object?> completion,
    String idempotencyKey,
  ) =>
      _http.request(
        'POST',
        '/api/v1/media/assets/${apiResourceId(assetId, 'assetId')}/complete',
        payload: versioned(completion, 'Media'),
        idempotencyKey: idempotencyKey,
      );

  Future<ApiResponse> createDownloadGrant(
    String assetId,
    Map<String, Object?> grant,
    String idempotencyKey,
  ) =>
      _http.request(
        'POST',
        '/api/v1/media/assets/${apiResourceId(assetId, 'assetId')}/download-grants',
        payload: versioned(grant, 'Media'),
        idempotencyKey: idempotencyKey,
      );

  Future<ApiResponse> updateRetention(
    String assetId,
    String? expiresAt,
    String idempotencyKey,
  ) =>
      _http.request(
        'PATCH',
        '/api/v1/media/assets/${apiResourceId(assetId, 'assetId')}/retention',
        payload: {'version': 1, 'expires_at': expiresAt},
        idempotencyKey: idempotencyKey,
      );

  Future<ApiResponse> renewRetention(
          String assetId, String requestedExpiresAt, String idempotencyKey,
          {String? expectedExpiresAt}) =>
      _http.request('POST',
          '/api/v1/media/assets/${apiResourceId(assetId, 'assetId')}/retention',
          payload: {
            'version': 1,
            'requested_expires_at': requestedExpiresAt,
            if (expectedExpiresAt != null)
              'expected_expires_at': expectedExpiresAt
          },
          idempotencyKey: idempotencyKey);

  Future<ApiResponse> deleteAsset(String assetId, String idempotencyKey) =>
      _http.request(
        'DELETE',
        '/api/v1/media/assets/${apiResourceId(assetId, 'assetId')}',
        payload: const {'version': 1},
        idempotencyKey: idempotencyKey,
      );
}
