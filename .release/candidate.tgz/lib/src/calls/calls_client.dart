library;

import '../http/transport.dart';

enum CallMediaProfile {
  audio('audio'),
  video720p('video-720p'),
  group720p('group-720p');

  const CallMediaProfile(this.wireName);
  final String wireName;
}

enum CallProcessingProfile {
  recordable('recordable'),
  e2eePrivate('e2ee_private');

  const CallProcessingProfile(this.wireName);
  final String wireName;
}

enum CallInfrastructureState {
  connecting('connecting'),
  active('active'),
  reconnecting('reconnecting');

  const CallInfrastructureState(this.wireName);
  final String wireName;
}

enum CallIntelligenceKind {
  transcript('transcript'),
  summary('summary');

  const CallIntelligenceKind(this.wireName);
  final String wireName;
}

enum CallMediaGrant {
  audioPublish('audio:publish'),
  videoPublish('video:publish'),
  screenPublish('screen:publish'),
  tracksSubscribe('tracks:subscribe'),
  participantRemove('participant:remove'),
  recordingControl('recording:control');

  const CallMediaGrant(this.wireName);
  final String wireName;
}

final class CallsClient {
  CallsClient({
    required String baseUrl,
    required String machineCredential,
    ApiTransport? transport,
    Duration timeout = const Duration(seconds: 5),
  }) : _http = JsonApiClient(
          baseUrl: baseUrl,
          machineCredential: machineCredential,
          transport: transport,
          timeout: timeout,
        );

  final JsonApiClient _http;

  Future<ApiResponse> createSession({
    required String callId,
    required CallMediaProfile mediaProfile,
    required CallProcessingProfile processingProfile,
    required DateTime expiresAt,
    required String idempotencyKey,
  }) =>
      _http.request(
        'POST',
        '/api/v1/calls/sessions',
        payload: versioned({
          'call_id': _opaqueReference(callId, 'callId'),
          'media_profile': mediaProfile.wireName,
          'processing_profile': processingProfile.wireName,
          'expires_at': expiresAt.toUtc().toIso8601String(),
        }, 'Calls'),
        idempotencyKey: idempotencyKey,
      );

  Future<ApiResponse> session(String callId) => _http.request(
        'GET',
        '/api/v1/calls/sessions/${_callReference(callId, 'callId')}',
      );

  Future<ApiResponse> createJoinCredential({
    required String callId,
    required String participantRef,
    required Set<CallMediaGrant> mediaGrants,
    required int expiresInSeconds,
    required String idempotencyKey,
  }) =>
      _http.request(
        'POST',
        '/api/v1/calls/sessions/${_callReference(callId, 'callId')}/join-credentials',
        payload: versioned({
          'participant_ref': _opaqueReference(participantRef, 'participantRef'),
          'media_grants': mediaGrants
              .map((grant) => grant.wireName)
              .toList(growable: false),
          'expires_in_seconds': expiresInSeconds,
        }, 'Calls'),
        idempotencyKey: idempotencyKey,
      );

  Future<ApiResponse> endSession(String callId, String idempotencyKey) =>
      _http.request(
        'DELETE',
        '/api/v1/calls/sessions/${_callReference(callId, 'callId')}',
        payload: const {'version': 1},
        idempotencyKey: idempotencyKey,
      );

  Future<ApiResponse> synchronizeState({
    required String callId,
    required CallInfrastructureState state,
    required String idempotencyKey,
  }) =>
      _http.request(
        'PUT',
        '/api/v1/calls/sessions/${_callReference(callId, 'callId')}/state',
        payload: {'version': 1, 'state': state.wireName},
        idempotencyKey: idempotencyKey,
      );

  Future<ApiResponse> removeParticipant({
    required String callId,
    required String participantRef,
    required String idempotencyKey,
  }) =>
      _http.request(
        'DELETE',
        '/api/v1/calls/sessions/${_callReference(callId, 'callId')}/participants/${_callReference(participantRef, 'participantRef')}',
        payload: const {'version': 1},
        idempotencyKey: idempotencyKey,
      );

  Future<ApiResponse> startRecording(String callId, String idempotencyKey) =>
      _processingRequest(callId, 'recording', idempotencyKey);

  Future<ApiResponse> stopRecording(String callId, String idempotencyKey) =>
      _processingRequest(callId, 'recording/stop', idempotencyKey);

  Future<ApiResponse> reconcileRecording(
          String callId, String idempotencyKey) =>
      _processingRequest(callId, 'recording/reconcile', idempotencyKey);

  Future<ApiResponse> startCaptions(String callId, String idempotencyKey) =>
      _processingRequest(callId, 'captions', idempotencyKey);

  Future<ApiResponse> stopCaptions(String callId, String idempotencyKey) =>
      _processingRequest(callId, 'captions/stop', idempotencyKey);

  Future<ApiResponse> reconcileCaptions(String callId, String idempotencyKey) =>
      _processingRequest(callId, 'captions/reconcile', idempotencyKey);

  Future<ApiResponse> requestIntelligence({
    required String callId,
    required CallIntelligenceKind kind,
    required String idempotencyKey,
  }) =>
      _processingRequest(
          callId, 'intelligence/${kind.wireName}', idempotencyKey);

  Future<ApiResponse> reconcileIntelligence({
    required String callId,
    required CallIntelligenceKind kind,
    required String idempotencyKey,
  }) =>
      _processingRequest(
          callId, 'intelligence/${kind.wireName}/reconcile', idempotencyKey);

  Future<ApiResponse> _processingRequest(
          String callId, String operation, String idempotencyKey) =>
      _http.request(
        'POST',
        '/api/v1/calls/sessions/${_callReference(callId, 'callId')}/$operation',
        payload: const {'version': 1},
        idempotencyKey: idempotencyKey,
      );
}

String _callReference(String value, String name) {
  final reference = _opaqueReference(value, name);
  if (reference.contains('/')) {
    throw ArgumentError.value(
        value, name, 'must be a bounded opaque path-safe ASCII reference');
  }
  return Uri.encodeComponent(reference);
}

String _opaqueReference(String value, String name) {
  if (value.isEmpty ||
      value.length > 128 ||
      !RegExp(r'^[!-~]+$').hasMatch(value)) {
    throw ArgumentError.value(
        value, name, 'must be a bounded opaque ASCII reference');
  }
  return value;
}
