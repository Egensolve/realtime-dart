library;

import 'dart:collection';

import 'calls_client.dart';

const callInvitationDedupeMax = 32;
const callInvitationMaxAge = Duration(minutes: 2);
const callNegotiationMaxAge = Duration(seconds: 30);
const callParticipantProjectionMax = 100;

enum CallUiState {
  idle,
  incomingRinging,
  outgoingRinging,
  connecting,
  active,
  reconnecting,
  ending,
  ended,
  declined,
  cancelled,
  expired,
  failed,
}

enum CallCanonicalState {
  ringing,
  connecting,
  active,
  reconnecting,
  ending,
  ended,
  declined,
  cancelled,
  expired,
  failed,
}

enum CallRecordingState {
  idle,
  requested,
  starting,
  recording,
  finalizing,
  playable,
  failed,
  stopped,
}

enum CallIntelligenceState {
  idle,
  disabled,
  pending,
  processing,
  ready,
  failed,
}

enum CallCaptionsState {
  idle,
  disabled,
  starting,
  active,
  stopping,
  stopped,
  failed,
}

enum CallQualityWarning {
  networkDegraded('network_degraded'),
  mediaDegraded('media_degraded'),
  providerDegraded('provider_degraded');

  const CallQualityWarning(this.wireName);
  final String wireName;
}

final class CallParticipantMediaState {
  CallParticipantMediaState({
    required String participantRef,
    required this.audio,
    required this.video,
    required this.screen,
  }) : participantRef = _opaque(participantRef, 'participantRef');

  final String participantRef;
  final bool audio;
  final bool video;
  final bool screen;

  @override
  bool operator ==(Object other) =>
      other is CallParticipantMediaState &&
      other.participantRef == participantRef &&
      other.audio == audio &&
      other.video == video &&
      other.screen == screen;

  @override
  int get hashCode => Object.hash(participantRef, audio, video, screen);
}

enum CallProcessingOutputKind {
  mediaAsset('media_asset'),
  externalStorage('external_storage');

  const CallProcessingOutputKind(this.wireName);
  final String wireName;
}

enum CallProcessingFailureReason {
  providerUnavailable('provider_unavailable'),
  providerTimeout('provider_timeout'),
  outputCopyFailed('output_copy_failed'),
  outputExpired('output_expired'),
  unsupported('unsupported'),
  rejected('rejected');

  const CallProcessingFailureReason(this.wireName);
  final String wireName;
}

final class CallProcessingOutput {
  CallProcessingOutput({required this.kind, required String ref})
      : ref = _opaque(ref, 'outputRef');

  final CallProcessingOutputKind kind;
  final String ref;

  @override
  bool operator ==(Object other) =>
      other is CallProcessingOutput && other.kind == kind && other.ref == ref;

  @override
  int get hashCode => Object.hash(kind, ref);
}

final class CallProcessingFailure {
  const CallProcessingFailure({required this.reason, required this.retryable});

  final CallProcessingFailureReason reason;
  final bool retryable;

  @override
  bool operator ==(Object other) =>
      other is CallProcessingFailure &&
      other.reason == reason &&
      other.retryable == retryable;

  @override
  int get hashCode => Object.hash(reason, retryable);
}

enum CallErrorCode {
  callExpired('calls.call_expired'),
  credentialExpired('calls.credential_expired'),
  forbidden('calls.forbidden'),
  callNotFound('calls.call_not_found'),
  payloadTooLarge('calls.payload_too_large'),
  signalingInvalid('calls.signaling_invalid'),
  processingIncompatibleWithE2ee('calls.processing_incompatible_with_e2ee');

  const CallErrorCode(this.wireName);
  final String wireName;
}

enum CallEffectType {
  fetchSnapshot,
  requestJoinCredential,
  connectRtc,
  restoreCallSubscription,
  stopLocalMedia,
  discardCredential,
  discardMediaKey,
  endOsCall,
  clearInvitationDedupe,
}

final class CallEffect {
  const CallEffect(this.type, [this.callId]);
  final CallEffectType type;
  final String? callId;

  @override
  bool operator ==(Object other) =>
      other is CallEffect && other.type == type && other.callId == callId;

  @override
  int get hashCode => Object.hash(type, callId);
}

final class CallProjection {
  CallProjection({
    required String installationRef,
    this.callId,
    this.uiState = CallUiState.idle,
    bool? outgoingInvitation,
    this.mediaProfile = CallMediaProfile.audio,
    this.processingProfile = CallProcessingProfile.recordable,
    this.snapshotCursor,
    List<String> invitationKeys = const [],
    List<String> joinedParticipantRefs = const [],
    List<CallParticipantMediaState> participantMediaStates = const [],
    this.qualityWarning,
    this.recordingState = CallRecordingState.idle,
    CallCaptionsState? captionsState,
    CallIntelligenceState? transcriptState,
    CallIntelligenceState? summaryState,
    this.credentialExpiresAt,
    this.negotiationEpoch,
    this.iceCandidateCount = 0,
    this.recordingOutput,
    this.transcriptOutput,
    this.summaryOutput,
    this.recordingFailure,
    this.captionsFailure,
    this.transcriptFailure,
    this.summaryFailure,
    this.lastError,
    this.snapshotRequired = false,
  })  : outgoingInvitation =
            outgoingInvitation ?? uiState == CallUiState.outgoingRinging,
        installationRef = _opaque(installationRef, 'installationRef'),
        invitationKeys = UnmodifiableListView(invitationKeys),
        joinedParticipantRefs = UnmodifiableListView(joinedParticipantRefs),
        participantMediaStates = UnmodifiableListView(participantMediaStates),
        captionsState = captionsState ??
            (processingProfile == CallProcessingProfile.e2eePrivate
                ? CallCaptionsState.disabled
                : CallCaptionsState.idle),
        transcriptState = transcriptState ??
            (processingProfile == CallProcessingProfile.e2eePrivate
                ? CallIntelligenceState.disabled
                : CallIntelligenceState.idle),
        summaryState = summaryState ??
            (processingProfile == CallProcessingProfile.e2eePrivate
                ? CallIntelligenceState.disabled
                : CallIntelligenceState.idle) {
    if (callId != null) _opaque(callId!, 'callId');
  }

  final String installationRef;
  final String? callId;
  final CallUiState uiState;
  final bool outgoingInvitation;
  final CallMediaProfile mediaProfile;
  final CallProcessingProfile processingProfile;
  final String? snapshotCursor;
  final List<String> invitationKeys;
  final List<String> joinedParticipantRefs;
  final List<CallParticipantMediaState> participantMediaStates;
  final CallQualityWarning? qualityWarning;
  final CallRecordingState recordingState;
  final CallCaptionsState captionsState;
  final CallIntelligenceState transcriptState;
  final CallIntelligenceState summaryState;
  final DateTime? credentialExpiresAt;
  final String? negotiationEpoch;
  final int iceCandidateCount;
  final CallProcessingOutput? recordingOutput;
  final CallProcessingOutput? transcriptOutput;
  final CallProcessingOutput? summaryOutput;
  final CallProcessingFailure? recordingFailure;
  final CallProcessingFailure? captionsFailure;
  final CallProcessingFailure? transcriptFailure;
  final CallProcessingFailure? summaryFailure;
  final CallErrorCode? lastError;
  final bool snapshotRequired;
  bool get terminalResurrected => false;

  CallProjection copyWith({
    Object? callId = _unset,
    CallUiState? uiState,
    bool? outgoingInvitation,
    CallMediaProfile? mediaProfile,
    CallProcessingProfile? processingProfile,
    Object? snapshotCursor = _unset,
    List<String>? invitationKeys,
    List<String>? joinedParticipantRefs,
    List<CallParticipantMediaState>? participantMediaStates,
    Object? qualityWarning = _unset,
    CallRecordingState? recordingState,
    CallCaptionsState? captionsState,
    CallIntelligenceState? transcriptState,
    CallIntelligenceState? summaryState,
    Object? credentialExpiresAt = _unset,
    Object? negotiationEpoch = _unset,
    int? iceCandidateCount,
    Object? recordingOutput = _unset,
    Object? transcriptOutput = _unset,
    Object? summaryOutput = _unset,
    Object? recordingFailure = _unset,
    Object? captionsFailure = _unset,
    Object? transcriptFailure = _unset,
    Object? summaryFailure = _unset,
    Object? lastError = _unset,
    bool? snapshotRequired,
  }) =>
      CallProjection(
        installationRef: installationRef,
        callId: identical(callId, _unset) ? this.callId : callId as String?,
        uiState: uiState ?? this.uiState,
        outgoingInvitation: outgoingInvitation ?? this.outgoingInvitation,
        mediaProfile: mediaProfile ?? this.mediaProfile,
        processingProfile: processingProfile ?? this.processingProfile,
        snapshotCursor: identical(snapshotCursor, _unset)
            ? this.snapshotCursor
            : snapshotCursor as String?,
        invitationKeys: invitationKeys ?? this.invitationKeys,
        joinedParticipantRefs:
            joinedParticipantRefs ?? this.joinedParticipantRefs,
        participantMediaStates:
            participantMediaStates ?? this.participantMediaStates,
        qualityWarning: identical(qualityWarning, _unset)
            ? this.qualityWarning
            : qualityWarning as CallQualityWarning?,
        recordingState: recordingState ?? this.recordingState,
        captionsState: captionsState ?? this.captionsState,
        transcriptState: transcriptState ?? this.transcriptState,
        summaryState: summaryState ?? this.summaryState,
        credentialExpiresAt: identical(credentialExpiresAt, _unset)
            ? this.credentialExpiresAt
            : credentialExpiresAt as DateTime?,
        negotiationEpoch: identical(negotiationEpoch, _unset)
            ? this.negotiationEpoch
            : negotiationEpoch as String?,
        iceCandidateCount: iceCandidateCount ?? this.iceCandidateCount,
        recordingOutput: identical(recordingOutput, _unset)
            ? this.recordingOutput
            : recordingOutput as CallProcessingOutput?,
        transcriptOutput: identical(transcriptOutput, _unset)
            ? this.transcriptOutput
            : transcriptOutput as CallProcessingOutput?,
        summaryOutput: identical(summaryOutput, _unset)
            ? this.summaryOutput
            : summaryOutput as CallProcessingOutput?,
        recordingFailure: identical(recordingFailure, _unset)
            ? this.recordingFailure
            : recordingFailure as CallProcessingFailure?,
        captionsFailure: identical(captionsFailure, _unset)
            ? this.captionsFailure
            : captionsFailure as CallProcessingFailure?,
        transcriptFailure: identical(transcriptFailure, _unset)
            ? this.transcriptFailure
            : transcriptFailure as CallProcessingFailure?,
        summaryFailure: identical(summaryFailure, _unset)
            ? this.summaryFailure
            : summaryFailure as CallProcessingFailure?,
        lastError: identical(lastError, _unset)
            ? this.lastError
            : lastError as CallErrorCode?,
        snapshotRequired: snapshotRequired ?? this.snapshotRequired,
      );
}

enum CallInputType {
  invitation,
  productSnapshot,
  snapshotDenied,
  localAccept,
  localDecline,
  localCancel,
  localEnd,
  remoteTerminal,
  socketDisconnected,
  socketReconnected,
  joinCredential,
  providerReconnected,
  providerOutage,
  participantJoined,
  participantLeft,
  participantMediaState,
  qualityWarning,
  rtcIceCandidate,
  rtcOffer,
  rtcAnswer,
  recordingState,
  captionsState,
  transcriptState,
  summaryState,
  requestRecording,
  requestCaptions,
  requestTranscript,
  requestSummary,
  accountLogout,
}

final class CallInput {
  const CallInput._(
    this.type, {
    this.callId,
    this.expiresAt,
    this.outgoing = false,
    this.canonicalState,
    this.snapshotCursor,
    this.mediaProfile,
    this.processingProfile,
    this.hidden = false,
    this.terminalState,
    this.participantRef,
    this.audio,
    this.video,
    this.screen,
    this.qualityWarning,
    this.negotiationEpoch,
    this.payloadBytes,
    this.recordingState,
    this.captionsState,
    this.intelligenceState,
    this.processingOutput,
    this.processingFailure,
  });

  factory CallInput.invitation({
    required String callId,
    required DateTime expiresAt,
    bool outgoing = false,
  }) =>
      CallInput._(CallInputType.invitation,
          callId: callId, expiresAt: expiresAt, outgoing: outgoing);
  factory CallInput.productSnapshot({
    required String callId,
    required CallCanonicalState state,
    String? snapshotCursor,
    CallMediaProfile? mediaProfile,
    CallProcessingProfile? processingProfile,
  }) =>
      CallInput._(CallInputType.productSnapshot,
          callId: callId,
          canonicalState: state,
          snapshotCursor: snapshotCursor,
          mediaProfile: mediaProfile,
          processingProfile: processingProfile);
  factory CallInput.snapshotDenied(String callId, {required bool hidden}) =>
      CallInput._(CallInputType.snapshotDenied, callId: callId, hidden: hidden);
  factory CallInput.localAccept(String callId) =>
      CallInput._(CallInputType.localAccept, callId: callId);
  factory CallInput.localDecline(String callId) =>
      CallInput._(CallInputType.localDecline, callId: callId);
  factory CallInput.localCancel(String callId) =>
      CallInput._(CallInputType.localCancel, callId: callId);
  factory CallInput.localEnd(String callId) =>
      CallInput._(CallInputType.localEnd, callId: callId);
  factory CallInput.remoteTerminal(String callId, CallUiState terminalState) =>
      CallInput._(CallInputType.remoteTerminal,
          callId: callId, terminalState: terminalState);
  factory CallInput.socketDisconnected(String callId) =>
      CallInput._(CallInputType.socketDisconnected, callId: callId);
  factory CallInput.socketReconnected(String callId) =>
      CallInput._(CallInputType.socketReconnected, callId: callId);
  factory CallInput.joinCredential(String callId, DateTime expiresAt) =>
      CallInput._(CallInputType.joinCredential,
          callId: callId, expiresAt: expiresAt);
  factory CallInput.providerReconnected(String callId) =>
      CallInput._(CallInputType.providerReconnected, callId: callId);
  factory CallInput.providerOutage(String callId) =>
      CallInput._(CallInputType.providerOutage, callId: callId);
  factory CallInput.participantJoined(String participantRef) =>
      CallInput._(CallInputType.participantJoined,
          participantRef: participantRef);
  factory CallInput.participantLeft(String participantRef) =>
      CallInput._(CallInputType.participantLeft,
          participantRef: participantRef);
  factory CallInput.participantMediaState({
    required String participantRef,
    required bool audio,
    required bool video,
    required bool screen,
  }) =>
      CallInput._(
        CallInputType.participantMediaState,
        participantRef: participantRef,
        audio: audio,
        video: video,
        screen: screen,
      );
  factory CallInput.qualityWarning(CallQualityWarning category) =>
      CallInput._(CallInputType.qualityWarning, qualityWarning: category);
  factory CallInput.rtcIceCandidate({
    required String negotiationEpoch,
    required DateTime expiresAt,
    required int candidateBytes,
  }) =>
      CallInput._(CallInputType.rtcIceCandidate,
          negotiationEpoch: negotiationEpoch,
          expiresAt: expiresAt,
          payloadBytes: candidateBytes);
  factory CallInput.rtcOffer({
    required String negotiationEpoch,
    required DateTime expiresAt,
    required int sdpBytes,
  }) =>
      CallInput._(CallInputType.rtcOffer,
          negotiationEpoch: negotiationEpoch,
          expiresAt: expiresAt,
          payloadBytes: sdpBytes);
  factory CallInput.rtcAnswer({
    required String negotiationEpoch,
    required DateTime expiresAt,
    required int sdpBytes,
  }) =>
      CallInput._(CallInputType.rtcAnswer,
          negotiationEpoch: negotiationEpoch,
          expiresAt: expiresAt,
          payloadBytes: sdpBytes);
  factory CallInput.recording(CallRecordingState state,
          {CallProcessingOutput? output, CallProcessingFailure? failure}) =>
      CallInput._(CallInputType.recordingState,
          recordingState: state,
          processingOutput: output,
          processingFailure: failure);
  factory CallInput.captions(CallCaptionsState state,
          {CallProcessingFailure? failure}) =>
      CallInput._(CallInputType.captionsState,
          captionsState: state, processingFailure: failure);
  factory CallInput.transcript(CallIntelligenceState state,
          {CallProcessingOutput? output, CallProcessingFailure? failure}) =>
      CallInput._(CallInputType.transcriptState,
          intelligenceState: state,
          processingOutput: output,
          processingFailure: failure);
  factory CallInput.summary(CallIntelligenceState state,
          {CallProcessingOutput? output, CallProcessingFailure? failure}) =>
      CallInput._(CallInputType.summaryState,
          intelligenceState: state,
          processingOutput: output,
          processingFailure: failure);
  const CallInput.requestRecording() : this._(CallInputType.requestRecording);
  const CallInput.requestCaptions() : this._(CallInputType.requestCaptions);
  const CallInput.requestTranscript() : this._(CallInputType.requestTranscript);
  const CallInput.requestSummary() : this._(CallInputType.requestSummary);
  const CallInput.accountLogout() : this._(CallInputType.accountLogout);

  final CallInputType type;
  final String? callId;
  final DateTime? expiresAt;
  final bool outgoing;
  final CallCanonicalState? canonicalState;
  final String? snapshotCursor;
  final CallMediaProfile? mediaProfile;
  final CallProcessingProfile? processingProfile;
  final bool hidden;
  final CallUiState? terminalState;
  final String? participantRef;
  final bool? audio;
  final bool? video;
  final bool? screen;
  final CallQualityWarning? qualityWarning;
  final String? negotiationEpoch;
  final int? payloadBytes;
  final CallRecordingState? recordingState;
  final CallCaptionsState? captionsState;
  final CallIntelligenceState? intelligenceState;
  final CallProcessingOutput? processingOutput;
  final CallProcessingFailure? processingFailure;
}

final class CallTransition {
  const CallTransition(this.projection,
      [this.effects = const [], this.ignoredReason]);
  final CallProjection projection;
  final List<CallEffect> effects;
  final CallErrorCode? ignoredReason;
}

CallTransition reduceCall(
    CallProjection current, CallInput input, DateTime now) {
  final nowUtc = now.toUtc();
  if (input.callId != null &&
      input.type != CallInputType.invitation &&
      input.type != CallInputType.productSnapshot) {
    _opaque(input.callId!, 'callId');
    if (current.callId != null && current.callId != input.callId) {
      return CallTransition(current);
    }
  }

  switch (input.type) {
    case CallInputType.invitation:
      final callId = _opaque(input.callId!, 'callId');
      if (!input.expiresAt!.isAfter(nowUtc)) {
        return _ignored(current, CallErrorCode.callExpired);
      }
      if (input.expiresAt!.isAfter(nowUtc.add(callInvitationMaxAge))) {
        return _ignored(current, CallErrorCode.signalingInvalid);
      }
      final key = '${current.installationRef}\u0000$callId';
      if (current.invitationKeys.contains(key) || current.callId == callId) {
        return CallTransition(current);
      }
      if (current.callId != null &&
          !_terminal.contains(current.uiState) &&
          (current.uiState != CallUiState.idle || current.snapshotRequired)) {
        return CallTransition(current);
      }
      final keys = [...current.invitationKeys, key];
      if (keys.length > callInvitationDedupeMax) keys.removeAt(0);
      return CallTransition(
        CallProjection(installationRef: current.installationRef).copyWith(
            callId: callId,
            outgoingInvitation: input.outgoing,
            invitationKeys: keys,
            snapshotRequired: true),
        [CallEffect(CallEffectType.fetchSnapshot, callId)],
      );
    case CallInputType.productSnapshot:
      final callId = _opaque(input.callId!, 'callId');
      if (current.callId != null && current.callId != callId) {
        return CallTransition(current);
      }
      final next = _snapshotUiState(input.canonicalState!, current);
      if (_terminal.contains(current.uiState) && !_terminal.contains(next)) {
        return CallTransition(current);
      }
      final processing = input.processingProfile ?? current.processingProfile;
      final projection = current.copyWith(
        callId: callId,
        uiState: next,
        snapshotCursor: input.snapshotCursor ?? current.snapshotCursor,
        mediaProfile: input.mediaProfile,
        processingProfile: processing,
        captionsState: processing == CallProcessingProfile.e2eePrivate
            ? CallCaptionsState.disabled
            : current.captionsState,
        transcriptState: processing == CallProcessingProfile.e2eePrivate
            ? CallIntelligenceState.disabled
            : current.transcriptState,
        summaryState: processing == CallProcessingProfile.e2eePrivate
            ? CallIntelligenceState.disabled
            : current.summaryState,
        snapshotRequired: false,
      );
      final effects = <CallEffect>[];
      if (next == CallUiState.active &&
          {CallUiState.connecting, CallUiState.reconnecting}
              .contains(current.uiState)) {
        effects.add(CallEffect(CallEffectType.requestJoinCredential, callId));
      }
      if (_terminal.contains(next)) {
        effects.addAll(_callCleanupEffects);
      }
      return CallTransition(projection, effects);
    case CallInputType.snapshotDenied:
      if (_terminal.contains(current.uiState)) return CallTransition(current);
      return CallTransition(
          CallProjection(
            installationRef: current.installationRef,
            callId: current.callId,
            invitationKeys: current.invitationKeys,
            lastError: input.hidden
                ? CallErrorCode.callNotFound
                : CallErrorCode.forbidden,
          ),
          _callCleanupEffects);
    case CallInputType.localAccept:
      if (_terminal.contains(current.uiState) ||
          current.uiState == CallUiState.ending) {
        return CallTransition(current);
      }
      return CallTransition(current.copyWith(
          callId: input.callId,
          uiState: CallUiState.connecting,
          snapshotRequired: true));
    case CallInputType.localDecline:
      if (_terminal.contains(current.uiState)) return CallTransition(current);
      return CallTransition(
          current.copyWith(
              callId: input.callId,
              uiState: CallUiState.ending,
              snapshotRequired: true),
          _callCleanupEffects);
    case CallInputType.localCancel:
    case CallInputType.localEnd:
      if (_terminal.contains(current.uiState)) return CallTransition(current);
      return CallTransition(
        current.copyWith(
            callId: input.callId,
            uiState: CallUiState.ending,
            snapshotRequired: true),
        _callCleanupEffects,
      );
    case CallInputType.remoteTerminal:
      if (!_terminal.contains(input.terminalState)) {
        return _ignored(current, CallErrorCode.signalingInvalid);
      }
      return CallTransition(
        current.copyWith(
            callId: input.callId,
            uiState: input.terminalState,
            snapshotRequired: true),
        _callCleanupEffects,
      );
    case CallInputType.socketDisconnected:
      if (!_mediaStates.contains(current.uiState) ||
          current.callId != input.callId) {
        return CallTransition(current);
      }
      return CallTransition(current.copyWith(
          callId: input.callId,
          uiState: CallUiState.reconnecting,
          snapshotRequired: true));
    case CallInputType.socketReconnected:
      return CallTransition(
          current, [CallEffect(CallEffectType.fetchSnapshot, input.callId)]);
    case CallInputType.joinCredential:
      
      if (!_canResumeMedia(current, input.callId!)) {
        return CallTransition(current);
      }
      if (!input.expiresAt!.isAfter(nowUtc)) {
        return CallTransition(
          current.copyWith(lastError: CallErrorCode.credentialExpired),
          [CallEffect(CallEffectType.requestJoinCredential, input.callId)],
          CallErrorCode.credentialExpired,
        );
      }
      return CallTransition(
        current.copyWith(credentialExpiresAt: input.expiresAt),
        [CallEffect(CallEffectType.connectRtc, input.callId)],
      );
    case CallInputType.providerReconnected:
      if (!_canResumeMedia(current, input.callId!)) {
        return CallTransition(current);
      }
      return CallTransition(
        current.copyWith(uiState: CallUiState.active, qualityWarning: null),
        [CallEffect(CallEffectType.restoreCallSubscription, input.callId)],
      );
    case CallInputType.providerOutage:
      if (!_mediaStates.contains(current.uiState) ||
          current.callId != input.callId) {
        return CallTransition(current);
      }
      return CallTransition(current.copyWith(
          uiState: CallUiState.reconnecting,
          qualityWarning: CallQualityWarning.providerDegraded,
          snapshotRequired: true));
    case CallInputType.participantJoined:
      if (_terminal.contains(current.uiState) ||
          current.uiState == CallUiState.ending) {
        return CallTransition(current);
      }
      final participantRef = _opaque(input.participantRef!, 'participantRef');
      if (current.joinedParticipantRefs.contains(participantRef)) {
        return CallTransition(current);
      }
      if (current.joinedParticipantRefs.length >=
          callParticipantProjectionMax) {
        return _ignored(current, CallErrorCode.signalingInvalid);
      }
      return CallTransition(current.copyWith(joinedParticipantRefs: [
        ...current.joinedParticipantRefs,
        participantRef
      ]));
    case CallInputType.participantLeft:
      final participantRef = _opaque(input.participantRef!, 'participantRef');
      return CallTransition(current.copyWith(
          joinedParticipantRefs: current.joinedParticipantRefs
              .where((value) => value != participantRef)
              .toList(),
          participantMediaStates: current.participantMediaStates
              .where((state) => state.participantRef != participantRef)
              .toList()));
    case CallInputType.participantMediaState:
      final participantRef = _opaque(input.participantRef!, 'participantRef');
      if (!current.joinedParticipantRefs.contains(participantRef)) {
        return _ignored(current, CallErrorCode.signalingInvalid);
      }
      final mediaState = CallParticipantMediaState(
        participantRef: participantRef,
        audio: input.audio!,
        video: input.video!,
        screen: input.screen!,
      );
      final participantMediaStates = [...current.participantMediaStates];
      final existingIndex = participantMediaStates
          .indexWhere((state) => state.participantRef == participantRef);
      if (existingIndex == -1) {
        participantMediaStates.add(mediaState);
      } else {
        participantMediaStates[existingIndex] = mediaState;
      }
      return CallTransition(
          current.copyWith(participantMediaStates: participantMediaStates));
    case CallInputType.qualityWarning:
      return CallTransition(
          current.copyWith(qualityWarning: input.qualityWarning));
    case CallInputType.rtcIceCandidate:
      final expiryError =
          _validateNegotiationExpiry(current, input.expiresAt!, nowUtc);
      if (expiryError != null) return expiryError;
      final epoch = _opaque(input.negotiationEpoch!, 'negotiationEpoch');
      if (input.payloadBytes! < 1 || input.payloadBytes! > 2048) {
        return _ignored(current, CallErrorCode.payloadTooLarge);
      }
      if (current.negotiationEpoch == epoch &&
          current.iceCandidateCount >= 64) {
        return _ignored(current, CallErrorCode.signalingInvalid);
      }
      return CallTransition(current.copyWith(
        negotiationEpoch: epoch,
        iceCandidateCount: current.negotiationEpoch == epoch
            ? current.iceCandidateCount + 1
            : 1,
      ));
    case CallInputType.rtcOffer:
    case CallInputType.rtcAnswer:
      final expiryError =
          _validateNegotiationExpiry(current, input.expiresAt!, nowUtc);
      if (expiryError != null) return expiryError;
      final epoch = _opaque(input.negotiationEpoch!, 'negotiationEpoch');
      if (input.payloadBytes! < 1 || input.payloadBytes! > 8192) {
        return _ignored(current, CallErrorCode.payloadTooLarge);
      }
      return CallTransition(
          current.copyWith(negotiationEpoch: epoch, iceCandidateCount: 0));
    case CallInputType.recordingState:
      if (current.processingProfile == CallProcessingProfile.e2eePrivate) {
        return _incompatible(current);
      }
      final recordingResult = _processingResult(
          successful: input.recordingState == CallRecordingState.playable,
          failed: input.recordingState == CallRecordingState.failed,
          output: input.processingOutput,
          failure: input.processingFailure,
          name: 'recording');
      return CallTransition(current.copyWith(
        recordingState: input.recordingState,
        recordingOutput: recordingResult.output,
        recordingFailure: recordingResult.failure,
      ));
    case CallInputType.captionsState:
      if (current.processingProfile == CallProcessingProfile.e2eePrivate) {
        return _incompatible(current);
      }
      final captionsFailure =
          _captionsFailure(input.captionsState!, input.processingFailure);
      return CallTransition(current.copyWith(
          captionsState: input.captionsState,
          captionsFailure: captionsFailure));
    case CallInputType.transcriptState:
      if (current.processingProfile == CallProcessingProfile.e2eePrivate) {
        return _incompatible(current);
      }
      final transcriptResult = _processingResult(
          successful: input.intelligenceState == CallIntelligenceState.ready,
          failed: input.intelligenceState == CallIntelligenceState.failed,
          output: input.processingOutput,
          failure: input.processingFailure,
          name: 'transcript');
      return CallTransition(current.copyWith(
          transcriptState: input.intelligenceState,
          transcriptOutput: transcriptResult.output,
          transcriptFailure: transcriptResult.failure));
    case CallInputType.summaryState:
      if (current.processingProfile == CallProcessingProfile.e2eePrivate) {
        return _incompatible(current);
      }
      final summaryResult = _processingResult(
          successful: input.intelligenceState == CallIntelligenceState.ready,
          failed: input.intelligenceState == CallIntelligenceState.failed,
          output: input.processingOutput,
          failure: input.processingFailure,
          name: 'summary');
      return CallTransition(current.copyWith(
          summaryState: input.intelligenceState,
          summaryOutput: summaryResult.output,
          summaryFailure: summaryResult.failure));
    case CallInputType.requestRecording:
    case CallInputType.requestCaptions:
    case CallInputType.requestTranscript:
    case CallInputType.requestSummary:
      return current.processingProfile == CallProcessingProfile.e2eePrivate
          ? _incompatible(current)
          : CallTransition(current);
    case CallInputType.accountLogout:
      return CallTransition(
        CallProjection(installationRef: current.installationRef),
        const [
          CallEffect(CallEffectType.stopLocalMedia),
          CallEffect(CallEffectType.discardCredential),
          CallEffect(CallEffectType.discardMediaKey),
          CallEffect(CallEffectType.endOsCall),
          CallEffect(CallEffectType.clearInvitationDedupe),
        ],
      );
  }
}

const _callCleanupEffects = [
  CallEffect(CallEffectType.stopLocalMedia),
  CallEffect(CallEffectType.discardCredential),
  CallEffect(CallEffectType.discardMediaKey),
  CallEffect(CallEffectType.endOsCall),
];

const _mediaStates = {
  CallUiState.connecting,
  CallUiState.active,
  CallUiState.reconnecting,
};

bool _canResumeMedia(CallProjection current, String callId) =>
    current.callId == callId &&
    _mediaStates.contains(current.uiState) &&
    !current.snapshotRequired;

const _terminal = {
  CallUiState.ended,
  CallUiState.declined,
  CallUiState.cancelled,
  CallUiState.expired,
  CallUiState.failed,
};
const _unset = Object();

CallUiState _snapshotUiState(CallCanonicalState state, CallProjection current) {
  
  if ({
        CallCanonicalState.connecting,
        CallCanonicalState.active,
        CallCanonicalState.reconnecting
      }.contains(state) &&
      !current.outgoingInvitation &&
      (current.uiState == CallUiState.incomingRinging ||
          (current.uiState == CallUiState.idle &&
              current.invitationKeys.isNotEmpty))) {
    return CallUiState.incomingRinging;
  }
  if (state == CallCanonicalState.ringing) {
    return current.outgoingInvitation
        ? CallUiState.outgoingRinging
        : CallUiState.incomingRinging;
  }
  return CallUiState.values.byName(state.name);
}

CallTransition? _validateNegotiationExpiry(
    CallProjection current, DateTime expiresAt, DateTime now) {
  if (!expiresAt.isAfter(now)) {
    return _ignored(current, CallErrorCode.callExpired);
  }
  if (expiresAt.isAfter(now.add(callNegotiationMaxAge))) {
    return _ignored(current, CallErrorCode.signalingInvalid);
  }
  return null;
}

CallTransition _ignored(CallProjection projection, CallErrorCode reason) =>
    CallTransition(projection.copyWith(lastError: reason), const [], reason);

CallTransition _incompatible(CallProjection projection) =>
    _ignored(projection, CallErrorCode.processingIncompatibleWithE2ee);

CallProcessingFailure? _captionsFailure(
    CallCaptionsState state, CallProcessingFailure? failure) {
  if (state == CallCaptionsState.failed) {
    if (failure == null) {
      throw ArgumentError(
          'captions failure requires one closed failure result.');
    }
    return failure;
  }
  if (failure != null) {
    throw ArgumentError(
        'captions failure is invalid outside the failed state.');
  }
  return null;
}

({CallProcessingOutput? output, CallProcessingFailure? failure})
    _processingResult({
  required bool successful,
  required bool failed,
  required CallProcessingOutput? output,
  required CallProcessingFailure? failure,
  required String name,
}) {
  if (successful) {
    if (output == null || failure != null) {
      throw ArgumentError('$name success requires one output and no failure.');
    }
    return (output: output, failure: null);
  }
  if (failed) {
    if (failure == null || output != null) {
      throw ArgumentError('$name failure requires one failure and no output.');
    }
    return (output: null, failure: failure);
  }
  if (output != null || failure != null) {
    throw ArgumentError('$name output or failure is invalid for this state.');
  }
  return (output: null, failure: null);
}

String _opaque(String value, String name) {
  if (value.isEmpty ||
      value.length > 128 ||
      !RegExp(r'^[!-~]+$').hasMatch(value)) {
    throw ArgumentError.value(
        value, name, 'must be a bounded opaque ASCII reference');
  }
  return value;
}
