library;

import 'dart:convert';
import 'dart:typed_data';

import 'package:http/http.dart' as http;

import '../lifecycle/adapters/url_policy.dart';

const apiMaxResponseBytes = 1048576;

enum ApiTransportErrorCode { requestFailed, responseTooLarge }

final class ApiTransportException implements Exception {
  const ApiTransportException(this.code, this.message);

  final ApiTransportErrorCode code;
  final String message;

  @override
  String toString() => 'ApiTransportException(${code.name}, $message)';
}

final class TransportResponse {
  const TransportResponse(this.status, this.headers, this.body);

  final int status;
  final Map<String, String> headers;
  final String body;
}

abstract interface class ApiTransport {
  Future<TransportResponse> send({
    required String method,
    required Uri uri,
    required Map<String, String> headers,
    String? body,
    required Duration timeout,
  });
}

final class HttpApiTransport implements ApiTransport {
  HttpApiTransport({http.Client? client}) : _client = client ?? http.Client();

  final http.Client _client;

  @override
  Future<TransportResponse> send({
    required String method,
    required Uri uri,
    required Map<String, String> headers,
    String? body,
    required Duration timeout,
  }) async {
    try {
      final request = http.Request(method, uri)..headers.addAll(headers);
      request.followRedirects = false;
      if (body != null) request.body = body;
      final streamed = await _client.send(request).timeout(timeout);
      final responseBody = await _readBoundedBody(streamed);
      return TransportResponse(
        streamed.statusCode,
        Map<String, String>.unmodifiable(streamed.headers),
        responseBody,
      );
    } on ApiTransportException {
      rethrow;
    } catch (_) {
      throw const ApiTransportException(
        ApiTransportErrorCode.requestFailed,
        'ERS HTTP request failed before a response was received.',
      );
    }
  }

  static Future<String> _readBoundedBody(http.StreamedResponse response) async {
    final contentLength = response.contentLength;
    if (contentLength != null && contentLength > apiMaxResponseBytes) {
      throw _responseTooLarge();
    }

    final bytes = BytesBuilder(copy: false);
    var totalBytes = 0;
    await for (final chunk in response.stream) {
      totalBytes += chunk.length;
      if (totalBytes > apiMaxResponseBytes) {
        throw _responseTooLarge();
      }
      bytes.add(chunk);
    }
    return utf8.decode(bytes.takeBytes());
  }
}

final class ApiResponse {
  const ApiResponse(this.status, this.data, this.idempotencyReplayed);

  final int status;
  final Map<String, Object?> data;
  final bool idempotencyReplayed;
}

final class ApiException implements Exception {
  const ApiException(this.httpStatus, this.code, this.message, this.details);

  final int httpStatus;
  final String code;
  final String message;
  final Map<String, Object?> details;

  bool get isRetryable => httpStatus == 429 || httpStatus >= 500;

  @override
  String toString() => 'ApiException($httpStatus, $code, $message)';
}

final class JsonApiClient {
  JsonApiClient({
    required String baseUrl,
    required String machineCredential,
    ApiTransport? transport,
    this.timeout = const Duration(seconds: 5),
  })  : _baseUri = _validateBaseUrl(baseUrl),
        _machineCredential = _validateCredential(machineCredential),
        _transport = transport ?? HttpApiTransport() {
    if (timeout < const Duration(seconds: 1) ||
        timeout > const Duration(seconds: 30)) {
      throw ArgumentError.value(timeout, 'timeout', 'must be 1–30 seconds');
    }
  }

  final Uri _baseUri;
  final String _machineCredential;
  final ApiTransport _transport;
  final Duration timeout;

  Future<ApiResponse> request(
    String method,
    String path, {
    Map<String, Object?>? payload,
    String? idempotencyKey,
  }) async {
    if (!const {'GET', 'POST', 'PUT', 'PATCH', 'DELETE'}.contains(method) ||
        !RegExp(r'^/api/v1/(media|artifacts|calls|intelligence)/[A-Za-z0-9._~!$&()*+,;=:@%/\-]*$')
            .hasMatch(path)) {
      throw ArgumentError('invalid ERS HTTP method or path');
    }
    if (idempotencyKey != null &&
        !RegExp(r'^[A-Za-z0-9._:\-]{1,128}$').hasMatch(idempotencyKey)) {
      throw ArgumentError.value(idempotencyKey, 'idempotencyKey', 'invalid');
    }
    final headers = <String, String>{
      'accept': 'application/json',
      'authorization': 'Bearer $_machineCredential',
      if (payload != null) 'content-type': 'application/json',
      if (idempotencyKey != null) 'idempotency-key': idempotencyKey,
    };
    final response = await _transport.send(
      method: method,
      uri: _baseUri.resolve(path),
      headers: headers,
      body: payload == null ? null : jsonEncode(payload),
      timeout: timeout,
    );
    if (utf8.encode(response.body).length > apiMaxResponseBytes) {
      throw _responseTooLarge();
    }
    final Object? decoded;
    try {
      decoded = jsonDecode(response.body);
    } on FormatException {
      throw StateError('ERS returned a non-JSON HTTP response');
    }
    if (decoded is! Map<String, dynamic>) {
      throw StateError('ERS returned a malformed HTTP response');
    }
    final data = Map<String, Object?>.from(decoded);
    if (response.status >= 200 && response.status < 300) {
      return ApiResponse(
        response.status,
        data,
        response.headers['x-idempotency-replayed'] == 'true',
      );
    }
    final rawDetails = data['details'];
    throw ApiException(
      response.status,
      data['code'] is String
          ? data['code']! as String
          : 'ers.control_plane_error',
      data['message'] is String
          ? data['message']! as String
          : 'ERS HTTP request failed.',
      rawDetails is Map<String, dynamic>
          ? Map<String, Object?>.from(rawDetails)
          : const <String, Object?>{},
    );
  }

  static Uri _validateBaseUrl(String value) {
    return requireSecureEndpoint(value, const {'https'});
  }

  static String _validateCredential(String value) {
    if (value.length < 32 || value.length > 512) {
      throw ArgumentError.value(
          value.length, 'machineCredential', 'invalid length');
    }
    return value;
  }
}

ApiTransportException _responseTooLarge() => const ApiTransportException(
      ApiTransportErrorCode.responseTooLarge,
      'ERS HTTP response exceeded the maximum size.',
    );

String apiResourceId(String value, String name) {
  if (value.length != 26 ||
      !RegExp(r'^[0-9A-HJKMNP-TV-Z]{26}$', caseSensitive: false)
          .hasMatch(value)) {
    throw ArgumentError.value(value, name, 'invalid ERS ULID');
  }
  return value;
}

Map<String, Object?> versioned(
    Map<String, Object?> payload, String capability) {
  if (payload.containsKey('version') && payload['version'] != 1) {
    throw ArgumentError('$capability request version must be 1');
  }
  return <String, Object?>{'version': 1, ...payload};
}
