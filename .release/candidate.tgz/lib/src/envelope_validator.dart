import 'dart:convert';

import 'envelope.dart';
import 'validation_error.dart';









final class EnvelopeValidator {
  const EnvelopeValidator._();

  static const int maxEnvelopeBytes = 10240;

  static final RegExp _token = RegExp(r'^[a-z][a-z0-9]*(-[a-z0-9]+)*$');
  static final RegExp _dottedToken = RegExp(
    r'^[a-z][a-z0-9]*(-[a-z0-9]+)*(\.[a-z][a-z0-9]*(-[a-z0-9]+)*)*$',
  );
  static final RegExp _opaqueId = RegExp(r'^[A-Za-z0-9_-]+$');
  static final RegExp _ulid = RegExp(r'^[0-9A-HJKMNP-TV-Z]{26}$');
  static final RegExp _dataUri =
      RegExp(r'^data:[^,]*;?base64?,', caseSensitive: false);
  static final RegExp _base64Charset = RegExp(r'^[A-Za-z0-9+/]+={0,2}$');
  static const int _base64MinLength = 256;
  static const int _base64MinDistinctChars = 20;
  static const int _maxPayloadRecursionDepth = 10;

  static Envelope parse(String raw) {
    if (utf8.encode(raw).length > maxEnvelopeBytes) {
      throw ValidationError(
        code: ValidationErrorCode.envelopeTooLarge,
        category: ValidationErrorCategory.sizeLimit,
        message: 'Envelope exceeds the $maxEnvelopeBytes byte limit.',
      );
    }

    final Object? decoded;
    try {
      decoded = jsonDecode(raw);
    } on FormatException catch (e) {
      throw ValidationError(
        code: ValidationErrorCode.envelopeInvalidJson,
        category: ValidationErrorCategory.parse,
        message: 'Envelope is not valid JSON: ${e.message}',
      );
    }

    if (decoded is! Map<String, dynamic>) {
      throw const ValidationError(
        code: ValidationErrorCode.envelopeMissingField,
        category: ValidationErrorCategory.schema,
        message: 'Envelope must be a JSON object.',
        path: '/version',
        details: {'field': 'version'},
      );
    }

    return _validateDecoded(decoded);
  }

  static Envelope _validateDecoded(Map<String, dynamic> data) {
    for (final field in const [
      'version',
      'id',
      'kind',
      'domain',
      'type',
      'tenant',
      'occurred_at',
      'payload',
    ]) {
      if (!data.containsKey(field)) {
        throw ValidationError(
          code: ValidationErrorCode.envelopeMissingField,
          category: ValidationErrorCategory.schema,
          message: 'Missing required field "$field".',
          path: '/$field',
          details: {'field': field},
        );
      }
    }

    if (data['version'] is! int || data['version'] != 1) {
      throw const ValidationError(
        code: ValidationErrorCode.envelopeUnsupportedVersion,
        category: ValidationErrorCategory.schema,
        message:
            'Unsupported envelope version; this validator only supports version 1.',
        path: '/version',
        details: {'field': 'version'},
      );
    }

    final rawKind = data['kind'];
    final kind = rawKind is String ? EnvelopeKind.tryFromWire(rawKind) : null;
    if (kind == null) {
      throw const ValidationError(
        code: ValidationErrorCode.envelopeInvalidKind,
        category: ValidationErrorCategory.schema,
        message: 'kind must be "durable" or "ephemeral".',
        path: '/kind',
        details: {'field': 'kind'},
      );
    }

    final id = data['id'];
    if (id is! String || !_ulid.hasMatch(id)) {
      throw const ValidationError(
        code: ValidationErrorCode.envelopeInvalidId,
        category: ValidationErrorCategory.schema,
        message: 'id must be a 26-character Crockford Base32 ULID.',
        path: '/id',
        details: {'field': 'id'},
      );
    }

    final domain = data['domain'];
    if (domain is! String ||
        domain.length > 64 ||
        !_dottedToken.hasMatch(domain)) {
      throw const ValidationError(
        code: ValidationErrorCode.envelopeInvalidDomain,
        category: ValidationErrorCategory.schema,
        message:
            'domain must be a lowercase dotted token of at most 64 characters.',
        path: '/domain',
        details: {'field': 'domain'},
      );
    }

    final type = data['type'];
    if (type is! String || type.length > 64 || !_dottedToken.hasMatch(type)) {
      throw const ValidationError(
        code: ValidationErrorCode.envelopeInvalidType,
        category: ValidationErrorCategory.schema,
        message:
            'type must be a lowercase dotted token of at most 64 characters.',
        path: '/type',
        details: {'field': 'type'},
      );
    }

    final tenant = data['tenant'];
    if (tenant is! String ||
        tenant.isEmpty ||
        tenant.length > 64 ||
        !_opaqueId.hasMatch(tenant)) {
      throw const ValidationError(
        code: ValidationErrorCode.envelopeInvalidTenant,
        category: ValidationErrorCategory.schema,
        message:
            'tenant must be 1-64 characters of letters, digits, "_", or "-".',
        path: '/tenant',
        details: {'field': 'tenant'},
      );
    }

    final occurredAtRaw = data['occurred_at'];
    final occurredAt =
        occurredAtRaw is String ? _parseRfc3339(occurredAtRaw) : null;
    if (occurredAt == null) {
      throw const ValidationError(
        code: ValidationErrorCode.envelopeInvalidTimestamp,
        category: ValidationErrorCategory.schema,
        message: 'occurred_at must be an RFC 3339 timestamp.',
        path: '/occurred_at',
        details: {'field': 'occurred_at'},
      );
    }

    Subject? subject;
    if (data.containsKey('subject')) {
      subject = _validateSubject(data['subject']);
    }

    Recovery? recovery;
    DateTime? expiresAt;
    if (kind == EnvelopeKind.durable) {
      if (!data.containsKey('recovery')) {
        throw const ValidationError(
          code: ValidationErrorCode.envelopeRecoveryRequired,
          category: ValidationErrorCategory.schema,
          message: 'Durable events require a recovery object.',
          path: '/recovery',
          details: {'field': 'recovery'},
        );
      }
      if (data.containsKey('expires_at')) {
        throw const ValidationError(
          code: ValidationErrorCode.envelopeExpiresAtNotAllowed,
          category: ValidationErrorCategory.schema,
          message: 'Durable events must not carry expires_at.',
          path: '/expires_at',
          details: {'field': 'expires_at'},
        );
      }
      recovery = _validateRecovery(data['recovery']);
    } else {
      if (!data.containsKey('expires_at')) {
        throw const ValidationError(
          code: ValidationErrorCode.envelopeExpiresAtRequired,
          category: ValidationErrorCategory.schema,
          message: 'Ephemeral events require expires_at.',
          path: '/expires_at',
          details: {'field': 'expires_at'},
        );
      }
      if (data.containsKey('recovery')) {
        throw const ValidationError(
          code: ValidationErrorCode.envelopeRecoveryNotAllowed,
          category: ValidationErrorCategory.schema,
          message: 'Ephemeral events must not carry recovery.',
          path: '/recovery',
          details: {'field': 'recovery'},
        );
      }
      final expiresAtRaw = data['expires_at'];
      expiresAt = expiresAtRaw is String ? _parseRfc3339(expiresAtRaw) : null;
      if (expiresAt == null) {
        throw const ValidationError(
          code: ValidationErrorCode.envelopeInvalidTimestamp,
          category: ValidationErrorCategory.schema,
          message: 'expires_at must be an RFC 3339 timestamp.',
          path: '/expires_at',
          details: {'field': 'expires_at'},
        );
      }
    }

    final payload = data['payload'];
    if (payload is! Map<String, dynamic>) {
      throw const ValidationError(
        code: ValidationErrorCode.envelopePayloadNotObject,
        category: ValidationErrorCategory.schema,
        message: 'payload must be a JSON object.',
        path: '/payload',
        details: {'field': 'payload'},
      );
    }

    if (_containsBinaryLikeString(payload, 0)) {
      throw const ValidationError(
        code: ValidationErrorCode.envelopePayloadBinaryRejected,
        category: ValidationErrorCategory.schema,
        message:
            'payload contains binary/media-like content, which is never transported over the realtime channel.',
        path: '/payload',
        details: {'field': 'payload'},
      );
    }

    return Envelope(
      version: 1,
      id: id,
      kind: kind,
      domain: domain,
      type: type,
      tenant: tenant,
      occurredAt: occurredAt,
      subject: subject,
      recovery: recovery,
      expiresAt: expiresAt,
      payload: payload,
    );
  }

  static Subject _validateSubject(Object? value) {
    if (value is! Map<String, dynamic>) {
      throw _invalidSubject;
    }
    final type = value['type'];
    final id = value['id'];
    if (type is! String ||
        type.isEmpty ||
        type.length > 64 ||
        !_token.hasMatch(type) ||
        id is! String ||
        id.isEmpty ||
        id.length > 128) {
      throw _invalidSubject;
    }
    return Subject(type: type, id: id);
  }

  static const _invalidSubject = ValidationError(
    code: ValidationErrorCode.envelopeInvalidSubject,
    category: ValidationErrorCategory.schema,
    message:
        'subject must be {type: lowercase token, id: 1-128 character string}.',
    path: '/subject',
    details: {'field': 'subject'},
  );

  static Recovery _validateRecovery(Object? value) {
    if (value is! Map<String, dynamic>) {
      throw _invalidRecovery;
    }
    final scope = value['scope'];
    final cursor = value['cursor'];
    if (scope is! String ||
        scope.isEmpty ||
        scope.length > 64 ||
        !_token.hasMatch(scope) ||
        cursor is! String ||
        cursor.isEmpty ||
        cursor.length > 128) {
      throw _invalidRecovery;
    }
    return Recovery(scope: scope, cursor: cursor);
  }

  static const _invalidRecovery = ValidationError(
    code: ValidationErrorCode.envelopeInvalidRecovery,
    category: ValidationErrorCategory.schema,
    message:
        'recovery must be {scope: lowercase token, cursor: 1-128 character string}.',
    path: '/recovery',
    details: {'field': 'recovery'},
  );

  static DateTime? _parseRfc3339(String value) {
    final match = RegExp(
      r'^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.\d+)?(Z|[+-]\d{2}:\d{2})$',
    ).firstMatch(value);
    if (match == null) return null;

    final year = int.parse(match.group(1)!);
    final month = int.parse(match.group(2)!);
    final day = int.parse(match.group(3)!);
    final hour = int.parse(match.group(4)!);
    final minute = int.parse(match.group(5)!);
    final second = int.parse(match.group(6)!);
    if (month < 1 || month > 12 || hour > 23 || minute > 59 || second > 60) {
      return null;
    }

    final normalized = DateTime.utc(year, month, day);
    if (normalized.year != year ||
        normalized.month != month ||
        normalized.day != day) {
      return null; 
    }

    try {
      return DateTime.parse(value);
    } on FormatException {
      return null;
    }
  }

  static bool _containsBinaryLikeString(Object? value, int depth) {
    if (depth > _maxPayloadRecursionDepth) return false;
    if (value is String) return _looksLikeBinary(value);
    if (value is Map) {
      for (final v in value.values) {
        if (_containsBinaryLikeString(v, depth + 1)) return true;
      }
      return false;
    }
    if (value is List) {
      for (final v in value) {
        if (_containsBinaryLikeString(v, depth + 1)) return true;
      }
      return false;
    }
    return false;
  }

  static bool _looksLikeBinary(String value) {
    if (_dataUri.hasMatch(value)) return true;
    if (value.length < _base64MinLength || !_base64Charset.hasMatch(value)) {
      return false;
    }
    final withoutPadding = value.replaceFirst(RegExp(r'=+$'), '');
    final distinct = withoutPadding.split('').toSet().length;
    return distinct >= _base64MinDistinctChars;
  }
}
