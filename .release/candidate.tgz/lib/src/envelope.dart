

enum EnvelopeKind {
  durable('durable'),
  ephemeral('ephemeral');

  const EnvelopeKind(this.wireValue);

  final String wireValue;

  static EnvelopeKind? tryFromWire(String value) {
    for (final kind in EnvelopeKind.values) {
      if (kind.wireValue == value) return kind;
    }
    return null;
  }
}



final class Subject {
  const Subject({required this.type, required this.id});

  final String type;
  final String id;
}



final class Recovery {
  const Recovery({required this.scope, required this.cursor});

  final String scope;
  final String cursor;
}



final class Envelope {
  const Envelope({
    required this.version,
    required this.id,
    required this.kind,
    required this.domain,
    required this.type,
    required this.tenant,
    required this.occurredAt,
    required this.subject,
    required this.recovery,
    required this.expiresAt,
    required this.payload,
  });

  final int version;
  final String id;
  final EnvelopeKind kind;
  final String domain;
  final String type;
  final String tenant;
  final DateTime occurredAt;
  final Subject? subject;
  final Recovery? recovery;
  final DateTime? expiresAt;
  final Map<String, dynamic> payload;
}
