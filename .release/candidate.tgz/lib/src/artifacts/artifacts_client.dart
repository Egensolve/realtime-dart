library;

import '../http/transport.dart';

final class ArtifactsClient {
  ArtifactsClient({
    required String baseUrl,
    required String machineCredential,
    ApiTransport? transport,
    Duration timeout = const Duration(seconds: 5),
  }) : _http = JsonApiClient(
          baseUrl: baseUrl,
          machineCredential: machineCredential,
          transport: transport,
          timeout: timeout,
        );

  final JsonApiClient _http;

  Future<ApiResponse> createArtifact(
          Map<String, Object?> artifact, String idempotencyKey) =>
      _http.request('POST', '/api/v1/artifacts/',
          payload: versioned(artifact, 'Artifacts'),
          idempotencyKey: idempotencyKey);

  Future<ApiResponse> artifact(String artifactId) => _http.request(
      'GET', '/api/v1/artifacts/${apiResourceId(artifactId, 'artifactId')}');

  Future<ApiResponse> createRevisionUploadIntent(String artifactId,
          Map<String, Object?> revision, String idempotencyKey) =>
      _http.request('POST',
          '/api/v1/artifacts/${apiResourceId(artifactId, 'artifactId')}/revisions/upload-intents',
          payload: versioned(revision, 'Artifacts'),
          idempotencyKey: idempotencyKey);

  Future<ApiResponse> revision(String artifactId, String revisionId) =>
      _http.request('GET',
          '/api/v1/artifacts/${apiResourceId(artifactId, 'artifactId')}/revisions/${apiResourceId(revisionId, 'revisionId')}');

  Future<ApiResponse> completeRevision(
    String artifactId,
    String revisionId,
    Map<String, Object?> completion,
    String idempotencyKey,
  ) =>
      _http.request('POST',
          '/api/v1/artifacts/${apiResourceId(artifactId, 'artifactId')}/revisions/${apiResourceId(revisionId, 'revisionId')}/complete',
          payload: versioned(completion, 'Artifacts'),
          idempotencyKey: idempotencyKey);

  Future<ApiResponse> publishRevision(
          String artifactId, String revisionId, String idempotencyKey) =>
      _http.request('PUT',
          '/api/v1/artifacts/${apiResourceId(artifactId, 'artifactId')}/current-revision',
          payload: {
            'version': 1,
            'revision_id': apiResourceId(revisionId, 'revisionId')
          },
          idempotencyKey: idempotencyKey);

  Future<ApiResponse> withdrawArtifact(
          String artifactId, String idempotencyKey) =>
      _http.request('POST',
          '/api/v1/artifacts/${apiResourceId(artifactId, 'artifactId')}/withdraw',
          payload: const {'version': 1}, idempotencyKey: idempotencyKey);
}
