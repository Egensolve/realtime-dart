# Changelog

## 0.3.1

- Discover effective Media retention and permitted tiering profiles.
- Update per-asset retention with explicit finite expiry or authorized null expiry.
- Support the retention PATCH request while preserving metadata-only transfers.

## 0.3.0

- License this public package under MIT.
- Add trusted-backend Media and Artifacts entrypoints and bounded HTTP support.
- Add a provider-neutral trusted-backend Calls client and bounded headless state machine.
- Preserve server-returned identifiers in their original case.

## 0.2.1

- Provide public protocol, lifecycle, recovery, presence, typing, and adapter APIs.
- Require encrypted remote HTTP and WebSocket endpoints.
- Bound HTTP responses and incoming realtime frames before decoding.
- Keep telemetry events bounded and free of product-defined identifiers.
- Limit the archive to the documented consumer-facing SDK surface.
