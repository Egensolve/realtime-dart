# Changelog

## 0.3.0

- License this public package under MIT.
- Add trusted-backend Media and Artifacts entrypoints and bounded HTTP support.
- Preserve server-returned identifiers in their original case.

## 0.2.1

- Provide public protocol, lifecycle, recovery, presence, typing, and adapter APIs.
- Require encrypted remote HTTP and WebSocket endpoints.
- Bound HTTP responses and incoming realtime frames before decoding.
- Keep telemetry events bounded and free of product-defined identifiers.
- Limit the archive to the documented consumer-facing SDK surface.
