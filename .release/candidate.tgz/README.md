# ERS Dart client

This framework-neutral package provides version 1 envelope validation, typed channel parsing,
connection lifecycle and recovery coordination, presence and typing helpers, and maintained HTTP
and WebSocket adapters.

```dart
import 'package:egensolve_realtime/egensolve_realtime.dart';

final envelope = EnvelopeValidator.parse(rawEnvelopeJson);
final channel = AccountChannel(
  tenant: 'example',
  actorType: 'user',
  actorId: '42',
).toChannelString();
```

Remote HTTP and WebSocket endpoints must use encrypted transport. Plaintext connections are
accepted only for loopback development hosts. Application backends remain responsible for user
authentication and channel authorization.

## Media and Artifacts (trusted Dart backends only)

Import `media.dart`, `artifacts.dart`, and `http.dart` for `MediaClient`, `ArtifactsClient`, and
their HTTP response/error/transport types. Both clients accept `baseUrl`, a server-held
`machineCredential`, an optional `ApiTransport` and a 1–30 second `timeout`.

Media supports upload intents, multipart part intents, completion, metadata, download grants and
deletion. Artifacts supports creation, revision upload/completion, publishing a ready revision and
withdrawal. These clients send version-1 JSON metadata, not file bytes. Your backend authorizes
product users and gives them short-lived instructions for direct provider upload/download.
Do not use machine credentials inside Flutter, browsers, mobile apps or widgets. Never log signed
URLs or upload tokens. Preserve returned IDs exactly, including letter case.

Reuse an idempotency key only for retries of the same mutation. Inspect `ApiResponse.data` for
provider instructions and readiness; completion acceptance alone does not imply readiness.
Handle `ApiException.httpStatus` and `code` and back off on retryable failures. Publish an earlier
ready revision to roll back an artifact.

## License

MIT. See [LICENSE](LICENSE).
